@extends('layouts.master')
@section('posts_menu', 'active')
@section('col-padrao', 'col-lg-9')

@section('search_att')
<form action='' method="POST">
            <div class="form-group">
            <h4><strong>
              Search</strong>
            </h4>
            <input type="text" class="form-control" id="searchAll" placeholder="Title / Channel name">
      </div>
        <hr>
      <div class="form-group">
            <h4><b>
              Gameworld</b>
            </h4>
            <select name="world" class="form-control" id="servers">
              <option value="all">All worlds</option>
               @foreach($worlds as $value)
                  <option value="{{$value->server}}">{{$value->server}}</option>
              @endforeach 
            </select>

            </div>
        <hr>
            <div class="form-group" id="pvptype">
            <h4><b>
              PvP Type</b>
            </h4>

     <div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" id="allpvp" name="pvptype" value="all" checked>
  <label class="custom-control-label" for="allpvp">All</label>
</div>

     <div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="openpvp" value="Open PvP">
  <label class="custom-control-label" for="openpvp">Open PvP</label>
</div>

    <div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="optinal" value="Optional PvP">
  <label class="custom-control-label" for="optinal">Optional PvP</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="retroopen" value="Retro Open PvP">
  <label class="custom-control-label" for="retroopen">Retro Open PvP</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="retrohardcore" value="Retro Hardcore PvP">
  <label class="custom-control-label" for="retrohardcore">Retro Hardcore PvP</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="hardcorepvp" value="Hardcore PvP">
  <label class="custom-control-label" for="hardcorepvp">Hardcore PvP</label>
</div>




            </div>
  <hr>
            <div class="form-group" id="radioplaymode">
            <h4><b>
              Play Mode</b>
            </h4>
<div class="custom-control custom-checkbox">
  <input type="radio" name="playmode" value="all" class="custom-control-input" id="allradio" value="all" checked>
  <label class="custom-control-label" for="allradio">All</label>
</div> 

            <div class="custom-control custom-checkbox">
  <input type="radio" name="playmode" value="pvp" class="custom-control-input" id="Player vs Player">
  <label class="custom-control-label" for="Player vs Player">Player vs Player</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" name="playmode" value="pvm" class="custom-control-input" id="Player vs MoB">
  <label class="custom-control-label" for="Player vs MoB">Player vs MoB</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" name="playmode" value="quests" class="custom-control-input" id="Quests">
  <label class="custom-control-label" for="Quests">Quests</label>
</div>

            </div>

</form>
@endsection
@section('findmode')
  <div class="form-row align-items-center">
    <div class="col-auto my-1">
      <select class="form-control form-control-lg" id="preferences">
        <option value="recent" selected>Most recent</option>
        <option value="viewed">Most viewed</option>
      </select>
    </div>
@endsection
@section('loop_vines')

@foreach($data as $value)

<div class="col-lg-3 col-md-5" style="padding:0 5px 0 0;">
              <div class="card rounded border-0 bg-transparent">
                @if($value->type=='0')
                  <?php $img = "<i class='fas fa-image'></i>"; ?>
                @else
                  <?php $img = "<i class='fas fa-video'></i>"; ?>
                @endif
                  @if($value->type == '0')
                  <a href="{{$value->channel_name}}/{{$value->id}}">
                <img class="lazy-fade card-img-top img-responsive" src="/images/default.jpg" data-src="/images/uploads/{{$value->link}}" alt="" style="max-width: 100%;height: auto;width:210px;height:118px;"></a>
                  @else
                <?php $q = explode('=', $value->link);?>
                <a href="{{$value->channel_name}}/{{$value->id}}"><img src="/images/default.jpg" class="lazy-fade card-img-top img-responsive" data-src="http://img.youtube.com/vi/{{ $q[1] }}/hqdefault.jpg" style="max-width: 100%;height: auto;width:210px;height:118px;"></a>
              
                @endif

                <div class="card-body">
                  <span class="card-title font-weight-bold">
                    <a href="{{$value->channel_name}}/{{$value->id}}"><?= $img ?> {{$value->title}}</a>
                  </span>
                  <div class="clearfix"></div>                
                  <small class="text-muted"><i class="fas fa-globe-americas"></i> {{$value->server}}</small>
                  <div class="clearfix"></div>
                  <a href="/{{$value->channel_name}}" class="hover-href"><small class=""><i class="fas fa-book"></i> {{$value->channel_name}}</small></a>
                  <div class="clearfix">
                  <small class="text-muted"><i class="far fa-eye"></i> {{$value->view}}</small>
                  <div class="clearfix"></div>
                  <small class="text-muted">  {{Carbon\Carbon::parse($value->created_at)->diffForHumans()}}</small>
                  </div>

                                    
                 </div>

              </div>
            </div>
 

  
  @endforeach
  <div class="row bg-light col-12">
    {{ $data->render("pagination::bootstrap-4") }}
  </div>

    @endsection  
  
