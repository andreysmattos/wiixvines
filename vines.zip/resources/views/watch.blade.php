@extends('layouts.master_channel')

@section('col-padrao', 'col-lg-12')
@section('bg_color', '')
@section('ch_color', 'bg-white rounded border')
<?php 
$bg_header = "bg-dark";
$ch_name_color = "text-light";
$ch_desc_color = "text-light";

$title_color = "";
$subtitle_color = "text-muted";

$text_color = "text-light";
$hr_color ="bg-light";

?>


@section('feed_vines')
@endsection

@section('loop_vines')

<section class="bg-white col-md-12 mb-3"  align="center" style="height:256px;">
<a href="/{{$name}}">
    @if($profileimage)
    <img src="/images/default.jpg" data-src="/images/profile-images/{{$profileimage}}" class="rounded-circle lazy ml-2 col-md-2 img-responsive mt-0" width="128px" height="128px" alt="">
    @else
    <img src="/images/default.jpg" data-src="/images/profile-images/default.png" class="lazy float-left ml-2 col-md-2 img-responsive mt-0" width="128px" height="128px" alt="">
    @endif

    
    <h1 class="display-4 font-weight-bold" style="margin:0 0 0 0;">{{$name}}</h1></a>
    {{-- <p class="lead text-muted">{{$desc}}</p> --}}

  
    <div class="clearfix"></div>
<div class="ml-2 mt-2" align="center">
 @if(auth::check() && auth::user()->channel_name != null && auth::user()->channel_name != $channel)
          @if(isset($ckfollow))
        <form action="{{route('unsubscribe')}}" method='POST'>
        {{csrf_field()}}
          <input type="hidden" value="{{$channel}}" name="name">
          <button class="btn btn-secondary" type="submit"><i class="fas fa-user-times"></i> unfollow [{{$subscribe}}] </button>
        </form>
                  @else      
      
      <form action="{{route('subscribe')}}" method='POST'>
        {{csrf_field()}}
        <input type="hidden" value="{{$channel}}" name="name">
        <button type="submit" class="btn btn-info my-2"><i class='fas fa-check'></i> Follow </button>
      </form>
        @endif
        @else
        <div class="input-group col-md-2">
        <div class="input-group-prepend">
          @if(auth::check())
          <button class="btn btn-secondary" type="button" ata-toggle="tooltip" data-placement="top" title="This is your channel." disabled>Follows</button>
        @else
          <button class="btn btn-secondary" type="button" ata-toggle="tooltip" data-placement="top" title="Login to follow" disabled>Follows</button>        
          @endif
        </div>
        <input type="text" class="form-control text-right" value="{{$subscribe}}" disabled>
      
        </div>
      @endif
</div>
</div>

</section>
<div class="container">
@foreach($vines as $value)
      <div class="row">
 <div class="col-md-2">
<div class="mb-3">
           <h5 class="bg-info rounded-right p-1 pl-2 text-white">Latest</h5>
          

          @foreach($data as $feed)
          <a href="/{{$feed->channel_name}}/{{$feed->id}}">
          <div class="bg-light border border-info mb-2 rounded p-1">
          <span class="font-weight-bold">{{$feed->title}}</span>
          <small class="text-muted"> {{$feed->server}}</small>
          @if($feed->type=='0')
        
          <img src="/images/default.jpg" data-src="/images/uploads/{{$feed->link}}" alt="{{$feed->title}}" class="lazy rounded border img-responsive" style="width:100%;height:auto;max-height:118px;">
          
        

          @else
          <?php $q = explode('=', $feed->link);?>
          <img class="lazy card-img-top rounded border img-responsive" data-src="http://img.youtube.com/vi/{{ $q[1] }}/hqdefault.jpg" src="/images/default.png" style="width:100%;height:auto;max-height:118px;" alt="">

          @endif
          <small class="text-muted">{{Carbon\Carbon::parse($feed->created_at)->format('d/m/Y H:i')}}</small>
          </div>
          </a>
          <div class="clearfix"></div>
          @endforeach
          <a href="/{{$feed->channel_name}}"><p class="text-center text-primary font-weight-bold">See all</p></a>

        </div>
      </div>


        <div class="col-md-8">
      @if($value->type == '0')
        
        <img class="lazy-fade tibiavines-watch img-responsive rounded border" src="/images/default.jpg" data-src="/images/uploads/{{$value->link}}" alt="Opa" style="max-width: 100%; height: auto;">
                @else

  <?php 
  $q = explode('=', $value->link )?>

        <div class="embed-responsive embed-responsive-16by9">
          <iframe src="https://www.youtube.com/embed/{{$q[1]}}?rel=0&amp;showinfo=0&amp;autoplay=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen class="lazy-fade tibiavines-watch embed-responsive-item rounded border"></iframe>
        </div>
        
        @endif
        <div class="col-md-8">
          <small>{{Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i')}} • <button type="button" class="border-0 bg-transparent" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Report</button></small>
    <h4 class="font-weight-bold ">{{$value->title}}       
        <small class="text-muted">{{$value->server}}</small>        
      </h4>
      <p>{{$value->description}}</p>
      @if( isset ($errors) && count($errors) > 0)
              <div class="alert alert-danger rounded">
                @foreach($errors->all() as $error)
                {{$error}}<br />
                @endforeach
              </div>
              @endif

             @if (session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
            @endif   
            {{-- REPORT MODAL  --}}
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Report photo or user</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="{{route('addReport')}}">
          {{csrf_field()}}
          <input type="hidden" name="page_id" value="{{$value->id}}">
          <input type="hidden" name="page_title" value="{{$value->title}}">
          <input type="hidden" name="channel_name" value="{{$channel}}">       
          <div class="form-group">
            <label for="title" class="col-form-label">Reason:</label>
            <select name="title" class="form-control" id="title">
              <option disabled selected>Select reason</option>

              <option value="nudity">Contains nudity</option>
              <option value="offensive">Offensive</option>
              <option value="personal image">Personal image</option>
              <option value="non-original content">Non-original content</option>
              <option value="identity theft">Identity theft</option>
            </select>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Message:</label>
            <textarea class="form-control" name="message" id="message-text"></textarea>
          </div>        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">Send Report</button>
      </div>
      </form>
    </div>
  </div>
</div>       
       {{-- REPORT MODAL  --}}
    </div>
<!-- 
        @INICIO DO FEED COMENTÁRIOS
        @INICIO DO FEED COMENTÁRIOS        
       -->
      
      <div class="card border-0">
        <h5 class="bg-info rounded p-1 pl-2 text-white">Comments</h5>
        <div class="card-body scroll-box">
          @foreach($comments as $comentario)
          <div class="clearfix">
            <a href="/{{$comentario->channel_name}}">
            @if($comentario->image)
            <img src="/images/profile-images/{{$comentario->image}}" class="float-left mr-2 rounded-circle" width="32" height="32" >
            @else
            <img src="/images/profile-images/default.png" class="float-left mr-2 rounded-circle" width="32" height="32" >
            @endif
            </a>
            @if(auth::check() && $comentario->user_id == auth::user()->id)
            <form action="{{route('commentDelete')}}" method="POST">
              {{csrf_field()}}
              <a href="" class="text-muted float-right">
                <input type="hidden" value="{{$comentario->id}}" name="id">
                <input type="hidden" value="{{$value->id}}" name="id_page">
                <button type="submit" class="border-0 text-muted bg-white btn"> <i class="fas fa-times"></i></button>
              </form>
            </a>
            @endif<a href="/{{$comentario->channel_name}}">
            <div class="content-heading"><h5>{{$comentario->channel_name}}</h5></div>
            </a>
          </div>
                  <span class="card-text">{{$comentario->comment}}</span><br>
          <small class="text-muted">{{ \Carbon\Carbon::parse($comentario->created_at)->diffForHumans() }}</small>
          <hr>
          @endforeach
        </div>

        <div class="card-footer bg-transparent">
          @if (Auth::check() && auth::user()->channel_name != null)
          <form action="{{route('insertComment')}}" method="POST">
            {{csrf_field()}}
            <input type="hidden" name="page_id" value="{{$value->id}}">
            
            <div class="container">
              <textarea name="comment" id="myText" cols="30" rows="10"></textarea>
            </div>
            <button type="submit" class="btn btn-info float-right mt-1 mr-3 rounded">Send</button>
              
              
          </form>
          @if( isset ($errors) && count($errors) > 0)
          <div class="alert alert-danger rounded">
            @foreach($errors->all() as $error)
            {{$error}}<br />
            @endforeach
          </div>
          @endif
          @else
          <div class="input-group mb-3">
            <input type="text" class="form-control" value="You are not logged in or no have channel" name="comment" aria-label="Recipient's username" aria-describedby="basic-addon2" disabled>
            <div class="input-group-append">
              <button class="btn btn-outline-secondary" disabled type="submit"><i class="fas fa-share-square"></i></button>
            </div>
          </div>
          @endif
        </div>
      </div>
      
    

    <!-- 
      @FIM DO COMENTÁRIOS FEED 
    -->
        </div>

    <div class="col-md-2">
<div class="mb-3">
          <h5 class="bg-info rounded-left p-1 pl-2 text-white">Recomend</h5>

          @foreach($follow->unique('channel_name') as $fav)
          <a href="/{{$fav->channel_name}}">
          <div class="bg-light border border-info mb-2 rounded p-1">
          <span class="font-weight-bold">{{$fav->channel_name}}</span>
           @if($fav->type=='0')
        
          <img src="/images/uploads/{{$fav->link}}" alt="{{$fav->title}}" class="rounded border img-responsive" style="width:100%;height:auto;max-height:118px;" >
          
        

          @else
          <?php $q = explode('=', $fav->link);?>
          <img class="card-img-top rounded border img-responsive" style="width:100%;height:auto;" src="http://img.youtube.com/vi/{{ $q[1] }}/hqdefault.jpg" alt="">

          @endif
          <small class="text-muted">{{Carbon\Carbon::parse($fav->created_at)->format('d/m/Y H:i')}}</small>
          </div>
          </a>
          <div class="clearfix"></div>
          @endforeach

        </div>

        <div>
          <h5 class="bg-info rounded-left p-1 pl-2 text-white">Publicity</h5>
          <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Publicity -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4248007486386492"
     data-ad-slot="5852868154"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
    
        </div>
      </div>


        
      </div>

    </div>
    


      <!-- /.row -->
@endforeach

    

      <!-- Page Features -->
     
      </div>
      <!-- /.row -->
    </div>

    
    <!-- /.container -->
  @endsection
  @section('footer')
 <footer class="page-footer rounded-top font-small">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2018 Copyright:
    <a href="/"> TibiaVines.com</a>
  </div>
  <!-- Copyright -->

</footer>
  @endsection