@extends('layouts.master_channel')

@section('col-padrao', 'col-lg-12')
@section('bg_color', '')
@section('ch_color', 'bg-white rounded border')
<?php 
$bg_header = "bg-dark";
$ch_name_color = "text-light";
$ch_desc_color = "text-light";

$title_color = "";
$subtitle_color = "text-muted";

$text_color = "text-light";
$hr_color ="bg-light";

?>


@section('feed_vines')
@endsection

@section('loop_vines')
<section class="bg-white col-md-12 mb-3"  align="center" style="height:256px;">

    @if($profileimage)
    <img src="/images/default.jpg" data-src="/images/profile-images/{{$profileimage}}" class="rounded-circle lazy ml-2 img-responsive" width="128px" height="128px" alt="">
    @else
    <img src="/images/default.jpg" data-src="/images/profile-images/default.png" class="rounded-circle lazy ml-2 img-responsive" width="128px" height="128px" alt="">
    @endif

    
    <h1 class="display-4 font-weight-bold" style="margin:0 0 0 0;">{{$name}}</h1>
    {{-- <p class="lead text-muted">{{$desc}}</p> --}}

  
    <div class="clearfix"></div>
<div class="ml-2 mt-2" align="center">

 @if(auth::check() && auth::user()->channel_name != null && auth::user()->channel_name != $channel)
          @if(isset($ckfollow))

        <form action="{{route('unsubscribe')}}" method='POST'>
        {{csrf_field()}}
          <input type="hidden" value="{{$channel}}" name="name">
          <button class="btn btn-secondary" type="submit"><i class="fas fa-user-times"></i> unfollow [{{$subscribe}}] </button>
        </form>

                  @else      
      
      <form action="{{route('subscribe')}}" method='POST'>
        {{csrf_field()}}
        <input type="hidden" value="{{$channel}}" name="name">
        <button type="submit" class="btn btn-info my-2"><i class='fas fa-check'></i> Follow </button>
      </form>
        @endif
        @else
        <div class="input-group col-md-2">
        <div class="input-group-prepend">
          @if(auth::check())
          <button class="btn btn-secondary" type="button" ata-toggle="tooltip" data-placement="top" title="This is your channel." disabled>Follows</button>
        @else
          <button class="btn btn-secondary" type="button" ata-toggle="tooltip" data-placement="top" title="Login to follow" disabled>Follows</button>        
          @endif
        </div>
        <input type="text" class="form-control text-right" value="{{$subscribe}}" disabled>
      
        </div>
      @endif

</div>
</div>
<div class="col-md-12" align="center">
<div class="col-md-8 rounded py-3 bg-light border ml-2 mb-2 text-center">

    
    <button type="button" class="mitem btn btn-light col-md-3">
    <div class="multi-itens"></div>
    </button>
    

    
    <button type="button" class="fitem btn btn-light col-md-3">
    <div class="feeditem"></div>
    </button>
    
    

  
  
</div>
</div>
<hr style="margin-top:0px;">
</section>     
      <div class="album col-md-12">
        <div class="container" id="vines_meio">
          <div class="multi" style="display:none;">
            @if(count($data) > 0)
                  <div class="row">

            @foreach($data as $content)
            @if($content->type=='0')
                  <?php $img = "<i class='fas fa-image'></i>"; ?>
                @else
                  <?php $img = "<i class='fas fa-video'></i>"; ?>
                @endif

            <div class="col-md-3" style="padding:0 5px 0 0;">    
            <a href="/{{$content->channel_name}}/{{$content->id}}">                   
              <div class="card mb-2 border-0 shadow-sm channelfeed">

                @if($content->type == '0')
                <img class="lazy card-img-top image" src="/images/default.jpg" data-src="/images/uploads/{{$content->link}}" alt="{{$content->title}}" style="width:250px;height:180px;">
                @else
                <?php $q = explode('=', $content->link);?>
                <img class="lazy card-img-top" src="/images/default.jpg" data-src="s://img.youtube.com/vi/{{ $q[1] }}/hqdefault.jpg" alt="{{$content->title}}" style="width:250px;height:180px;">
                @endif
                <div class="middle">
                  <div class="text text-left bg-light">             
                  <div class="clearfix"></div>             
                  <small><i class="fas fa-globe-americas"></i> {{$content->server}}</small>
                  <div class="clearfix"></div>                  
                  <div class="clearfix">
                  <small><i class="far fa-eye"></i> {{$content->view}}</small>
                  <div class="clearfix"></div>
                  <small class="text-muted">  {{Carbon\Carbon::parse($content->created_at)->diffForHumans()}}</small>
                  </div></div>
                  
                </div>
                <span class="font-weight-bold ml-2 mt-1 text-muted" style="overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;line-height: 120%;"><?=$img ?> {{$content->title}}</span>
              </div>
              </a>
            </div>


              @endforeach
          </div>
            @else
            <h1 class="text-center font-weight-bold">Aff, this channel is empty... 🙁</h1>
            @endif

          </div>
          <div class="feed" style="display:none;">
            @if(count($data) > 0)
<div class="col-md-12" align="center">
          <div class="card mb-4 col-md-8 border-0 text-left">
        @foreach($data as $value)
          @if($value->type=='0')
                  <?php $img = "<i class='fas fa-image'></i>"; ?>
                @else
                  <?php $img = "<i class='fas fa-video'></i>"; ?>
                @endif

          <!-- Blog Post -->
          
            @if($value->type =='0')

            <img class="lazy img-responsive" style="max-width: 100%; height: auto;" data-src="/images/uploads/{{$value->link}}" src="/images/default.jpg" />

            @else

              <?php $q = explode('=', $value->link ); ?>
            <div class="embed-responsive embed-responsive-16by9">
          <iframe src="https://www.youtube.com/embed/{{$q[1]}}?rel=0&amp;showinfo=0&amp;autoplay=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen class="lazy-fade embed-responsive-item rounded border"></iframe>
        </div>
            @endif



            <div class="card-body">
              <h2 class="card-title"><?= $img ?> {{$value->title}}</h2>
              <p class="card-text">{{$value->description}}</p>
              <p class="card-text text-muted">{!!app(App\Http\Controllers\commentController::class)->countComment($value->id)!!} comments</p>
              <a href="/{{$value->channel_name}}/{{$value->id}}" class="btn btn-info">Go to Post</a>
            </div>
            <div class="card-footer text-muted">
              Posted {{Carbon\Carbon::parse($value->created_at)->diffForHumans()}}
            </div>

          <hr>
      @endforeach
          </div>
          @endif

          
            
          </div>
          </div>
      </div>
	@endsection
	@section('footer')
 <footer class="page-footer rounded-top font-small">
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2018 Copyright:
    <a href="/"> TibiaVines.com</a>
  </div>
  <!-- Copyright -->

</footer>
<script>
  $(document).ready(function(){
  $('.multi').show();
  $('.mitem').addClass("active");


    $('.mitem').click(function () {
      $('.feed').hide();      
      $('.multi').show();
      $('.fitem').removeClass("active");

      $('.mitem').addClass("active");


});

        $('.fitem').click(function () {
        $('.multi').hide();
        $('.feed').show();
      $('.mitem').removeClass("active");
      $('.fitem').addClass("active");



});

    
  })
</script>
	@endsection