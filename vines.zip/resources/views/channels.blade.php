@extends('layouts.master')
@section('channel_menu', 'active')


@section('col-padrao', 'col-lg-12')

@section('feed_vines')
@endsection

@section('loop_vines')

@foreach($channels as $value)

<div class="col-lg-3 col-md-5 mb-3">
              <div class="card rounded">
                  <a href="/{{$value->name}}">
                <a href="{{$value->name}}">
                	@if($value->image)
                	<img class="card-img-top img-responsive" src="/images/profile-images/{{$value->image}}" style="max-width: 100%;height: auto;">
                	@else
                	<img class="card-img-top img-responsive" src="/images/profile-images/default.png" style="max-width: 100%;height: auto;">

                	@endif

                </a>


                <div class="card-body">
                  <span class="card-title font-weight-bold">
                    <a href="/{{$value->name}}">{{$value->name}}</a>
                  </span>
                  <div class="clearfix"></div>
                  {{$value->description}}
                  <hr>

                  <small class="text-muted"><i class="fas fa-globe-americas"></i> {{Carbon\Carbon::parse($value->created_at)->diffForHumans()}}</small>
                  <div class="clearfix"></div>
                  <small class="text-muted"><i class="fas fa-bookmark"></i> {{$value->subscribe}} following</small>    
                  <div class="clearfix"></div>            

                  <a href="/{{$value->name}}" class="hover-href"><small class=""><i class="fas fa-book"></i> {{$value->name}}</small></a>

                  <div class="clearfix">
                  <div class="clearfix"></div>
                  </div>

                                    
                 </div>

              </div>
            </div>
 

	
	@endforeach
  <div class="row bg-light col-12">
    {{ $channels->render("pagination::bootstrap-4") }}
  </div>

  @endsection
  @section('footer')

  @endsection