@extends('layouts.feed_master')
@section('feed_menu', 'active')
@section('feed')

          <!-- Blog Entries Column -->
<div class="col-md-8 rounded py-3 text-left bg-light border ml-2 mb-2 text-center">

    <a href="/user/upload-photo" target="_blank" >
    <button type="button" class="btn btn-light col-md-3">
    <div class="photo"></div>
    <div class="clearfix"></div>
    <small>Upload</small>
    <small>Photo</small>    
    </button>
    </a>

    <a href="/user/upload-vine" target="_blank">
    <button type="button" class="btn btn-light col-md-3">
    <div class="video"></div>
    <div class="clearfix"></div>
    <small>Upload Video</small>    
    </button>
    </a>


    <a href="/{{auth::user()->channel_name}}" target="_blank">
    <button type="button" class="btn btn-light col-md-3">
    <div class="channel"></div>
    <div class="clearfix"></div>
    <small>My channel</small>    
    </button>
    </a>
    

  
  
</div>
        <div class="col-md-8 rounded py-3 text-left bg-white border ml-2" id="post-data">          
          @include('data')
          <div class="ajax-load text-center" style="display:none">
  <p><img src="https://demo.itsolutionstuff.com/plugin/loader.gif">Loading More post</p>
</div>
        </div>
        
        <script>
          var imgs = $(".tibiavines-images-load");
    $.each(imgs, function () {
        var $this = $(this);
        var im = new Image();
        im.onload = function () {
            var theImage = $this;
            $this.hide("slow");
            theImage[0].src = im.src;
            $this.show('fast');
        };
        im.src = $this.data("mainsrc");
    });

        </script>
  	@endsection  

    @section('widgets')
    @if(count($widgets)> 0)
    <div class="card border bg-light rounded mb-3 text-left" style="max-width: 18rem;">

  <h5 class="card-header rounded-top">Others channels</h5>
  <div class="card-body">
    
    @foreach($widgets as $widget)
    <a href="/{{$widget->name}}">
    <div class="clearfix">
      @if($widget->image)
      <img data-src="/images/profile-images/{{$widget->image}}" class="lazy-none float-left mr-2 rounded-circle" width="32" height="32" >
      @else
     <img data-src="/images/profile-images/default.png" class="lazy-none float-left mr-2 rounded-circle" width="32" height="32" >
      @endif

    <h5 class="card-title font-weight-bold ">{{$widget->name}}</h5>
      </div>
      </a>  
            <form action="{{route('subscribe')}}" method='POST'>
        {{csrf_field()}}
        <input type="hidden" value="{{$widget->name}}" name="name">
        <button type="submit" class="btn btn-outline-secondary"><i class='fas fa-check'></i> Follow </button>
      </form>
    <hr>
    @endforeach
  </div>
</div>
@endif

    @endsection

