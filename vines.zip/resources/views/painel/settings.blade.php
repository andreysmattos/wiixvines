@extends('painel.layouts.newbase')
@section('menu')
        <div class="sidebar">
        
            <nav class="sidebar-nav" id="sidebar">
                <ul class="nav">
                    <li class="nav-title">Dashboard</li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link ">
                            <i class="fas fa-tachometer-alt"></i> Sumary
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="last-interactions" class="nav-link active">
                            <i class="fab fa-angellist"></i> Latest interactions 
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link">
                            <i class="fas fa-address-book"></i> Subscribes
                        </a>
                    </li>


                    <li class="nav-title">Channel Library</li>

                    <li class="nav-item">
                        <a href="upload-photo" class="nav-link">
                            <i class="fas fa-image"></i> Upload Photo
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="upload-vine" class="nav-link">
                            <i class="fas fa-video"></i> Upload Vines
                        </a>
                    </li>
                
                    <li class="nav-item">
                        <a href="studio" class="nav-link" disabled>
                            <i class="fas fa-tasks"></i> Studio
                        </a>
                    </li>
                   
                    <li class="nav-item">
                        <a href="vines" class="nav-link">
                            <i class="fas fa-sliders-h"></i> Vines manager
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link disabled">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </li>                 


                 </ul>
          
               </li>



                   
                </ul>
            </nav>
        </div>
@endsection
@section('page')
<div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">

                  <div class="card mb-3 text-left" style="width: 100%;height:100%">
  <div class="card-header bg-light">Last Interactions</div>
  <div class="card-body" id="interaction-page">
    <div class="clearfix">
Loading...
</div>
    @foreach($data as $value)
    @if(isset($check))

      
    @else
    

      
      <p>Basically, you don't have anything new!</p>
    
    <hr>
    @endif
    @endforeach


  </div>
  <div class="card-footer bg-transparent">
  </div>
</div>

      </div>


                </div>
</div>
</div>
</div>
</div>

@endsection