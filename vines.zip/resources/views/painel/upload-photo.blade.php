@extends('painel.layouts.newbase')
@section('menu')
        <div class="sidebar">
        
            <nav class="sidebar-nav" id="sidebar">
                <ul class="nav">
                    <li class="nav-title">Dashboard</li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Sumary
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="last-interactions" class="nav-link">
                            <i class="fab fa-angellist"></i> Latest interactions 
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link">
                            <i class="fas fa-address-book"></i> Subscribes
                        </a>
                    </li>


                    <li class="nav-title">Channel Library</li>

                    <li class="nav-item">
                        <a href="upload-photo" class="nav-link active">
                            <i class="fas fa-image"></i> Upload Photo
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="upload-vine" class="nav-link">
                            <i class="fas fa-video"></i> Upload Vines
                        </a>
                    </li>
                
                    <li class="nav-item">
                        <a href="studio" class="nav-link" disabled>
                            <i class="fas fa-tasks"></i> Studio
                        </a>
                    </li>
                   
                    <li class="nav-item">
                        <a href="vines" class="nav-link">
                            <i class="fas fa-sliders-h"></i> Vines manager
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link disabled">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </li>                 


                 </ul>
          
               </li>



                   
                </ul>
            </nav>
        </div>
@endsection
@section('page')
<script type="text/javascript">
         function isYoutubeVideo(url)
        {
  var v = /^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
  return (url.match(v)) ? RegExp.$1 : false;
        }

    $(document).ready(function(){

        $('#yblink').keyup(function(){

            var value = $(this).val();
            var urlvideo = "https://www.youtube.com/"+value;
             isYoutubeVideo(urlvideo)
            if(isYoutubeVideo(urlvideo) == false){
                $('#linkerror').text('Invalid youtube link!');
                return false;
                }else if(isYoutubeVideo(urlvideo) != false){

                $('#linkerror').text('Good Link!');
                return true;
                }
          })



    })

    function validaForm(frm) {                
                var vserver = frm.server.value;

               //World valida
                if(empty(server)){
                    $("#worlderro").html('Choose the server.');
                    return false;
                }
                if(vserver == '1'){
                    $("#worlderro").html('Choose the server.');
                    return false;
                }
                if(vserver == 'Select the server'){
                    $("#worlderro").html('Choose the server.');
                    return false;
                }


    }
</script>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header bg-light">
                                Upload Vine 
                            </div>
                              @if( isset ($errors) && count($errors) > 0)
              <div class="alert alert-danger rounded">
                @foreach($errors->all() as $error)
                {{$error}}<br />
                @endforeach
              </div>
              @endif
                                
                                
                                        @if(session()->has('msgkeycode'))
                                        <div class="alert alert-danger rounded">
                                            {{session()->get('msgkeycode')}}<br />
                                        </div>
                                         {{session()->forget('msgkeycode')}}
                                        @endif

                            <div class="card-body">
    
                                <div class="row">

                                    <div class="col-md-12">

{{Form::open(['route' => 'photoInsert', 'files' => true])}}
                                        <div class="form-group">
                                            <label for="title" class="form-control-label">Title</label>
                                            <input id="title" name="title" value="{{old('title')}}" maxlength="50" minlength="3" class="form-control" autocomplet='off' required>
                                            <div id="titleerro" class="text-danger pl-3 font-weight-light"></div>
                                        </div>
                                    </div>
                                   </div>      
                             <div class="row mb-2">
                                 <div class="col-md-12" id="ybform">
                                    <div class="form-group">
                                    <label for="yblink">Photo: *Max size: 3MB</label>
                                        <div class="input-group">
                                            
                                                {{Form::file('link', ['required'])}}
                                    
                                        </div>
                                        <span class="text-danger" id="linkerror"></span>
                                        </div>
                                        
                                </div>
                                
                            </div>

                            <div class="row">
                                <div class="col-md-12">

                                        <div class="form-group">
                                            <label for="worldselect">Server:</label>
                            <select class="form-control" id="worldselect" name="server" required>
                                <option disabled selected value>Select the server</option>
                                                      
                                        @for($i=1; $i < $countj; $i++)
                                                                                    
                                                <option value="{{$json[0]->worlds[$i]}}">{{$json[0]->worlds[$i]}}</option>
                                        @endfor
                                            </select>

                                        </div>
                                        <div id="worlderro" class="text-danger pl-3 font-weight-light"></div>
                                </div>




                                </div>
                                
                                   <div class="row">
                                    <div class="col-md-12">  
                                        <div class="form-group">
                                 <div class="input-group">

    <label for="desc">Description:</label>
  </div> <textarea class="form-control" aria-label="With textarea" id="desc" name="description" maxlength="200" rows="5">{{old('description')}}</textarea>
  

<div id="descerro" class="text-danger pl-3 font-weight-light"></div>
</div>
</div>
</div>

                                                        <button type="submit" class="form-control rounded cursor_pointer btn btn-info btn-outline-info border border-info font-weight-bold">Upload</button>
                             {{Form::close()}}

            </div>
        </div>
    </div>
</div>
@endsection