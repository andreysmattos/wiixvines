<!DOCTYPE HTML>
<html lang="{{ app()->getLocale() }}">
    <head>
        <title>TibiaVines - Feed</title>
        <link href="css/style.css" rel='stylesheet' type='text/css' />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" type="image/x-icon" href="../images/fav-icon.png" />
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
        </script>
        <!----webfonts---->
        <script
        src="https://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
        crossorigin="anonymous"></script>
        <!----//webfonts---->

        <link href="{{ asset('/css/main.css') }}" rel="stylesheet">
        <link href="{{ asset('/css/all.css') }}" rel="stylesheet">
        <link href="{{ asset('/font-awesome/css/all.css') }}" rel="stylesheet">
        <link href="{{ asset('/css/styles-auth.css') }}" rel="stylesheet">
        <!-- scripts -->
        <script src="{{ asset('/js/bootstrap.bundle.js') }}"></script>
            {{-- EMOJIS --}}

  <link rel='stylesheet' type='text/css' href='https://fonts.googleapis.com/css?family=Open+Sans:400,700'>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/3.0.3/normalize.min.css" media="screen">
  <!--<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/emojione/1.5.2/assets/sprites/emojione.sprites.css" media="screen">-->
  <link rel="stylesheet" type="text/css" href="stylesheet.css" media="screen">
  <link rel="stylesheet" type="text/css" href="/dist/emojionearea.min.css" media="screen">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" media="screen">
  <link rel="stylesheet" type="text/css" href="http://mervick.github.io/lib/google-code-prettify/skins/tomorrow.css" media="screen">
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  <!--<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/emojione/1.5.2/lib/js/emojione.min.js"></script>-->
  <!--<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/emojione@3.1.2/lib/js/emojione.min.js"></script>-->
  <!--<script type="text/javascript" src="../node_modules/emojione/lib/js/emojione.js"></script>-->
  <script type="text/javascript" src="http://mervick.github.io/lib/google-code-prettify/prettify.js"></script>
  <!--<script>
    window.emojioneVersion = "3.1";
  </script>-->
  <script type="text/javascript" src="/dist/emojionearea.js"></script>

  {{-- EMOJIS FIM --}}
  
            </head>
    <script>
  $(document).ready(function(){

     function doPoll(){
      
$value= 'oi';
 
$.ajax({
 
type : 'get',
 
url : '{{route('fastinteraction')}}',
 
data:{'search':$value},
 
success:function(data){
 
$('#fast-interaction').html(data);
 
}
 
});
setTimeout(doPoll, 3000);
}

$(function() {
  setTimeout(doPoll, 3000);
});


     function doPollTwo(){
      
      $value= 'dois';
 
$.ajax({
 
type : 'get',
 
url : '{{route('interactionpage')}}',
 
data:{'search':$value},
 
success:function(data){
 
$('#interaction-page').html(data);
 
}
 
});
setTimeout(doPollTwo, 3000);
}

$(function() {
  setTimeout(doPollTwo, 3000);
});


     });

    </script>
    <body>
        <div class="page-wrapper">
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" style="-webkit-box-shadow: 0px 5px 5px 0px rgba(0,0,0,0.75);
-moz-box-shadow: 0px 5px 5px 0px rgba(0,0,0,0.75);
box-shadow: 0px 5px 5px 0px rgba(0,0,0,0.75);">
       <div class="container">          

         <a class="navbar-brand" href="/"><img src="/images/logo.png" alt="TibiaVines" height="40"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link @yield('posts_menu')" href="/">Posts
                <span class="sr-only">(current)</span>
              </a>
            </li> 
            <li class="nav-item @yield('channel_menu')">
              <a class="nav-link" href="/channels">Channels
                <span class="sr-only">(current)</span>
              </a>
            </li>            
            @if(auth::check())
            <li class="nav-item @yield('feed_menu')">
              <a class="nav-link" href="/feed">Feed
                <span class="sr-only">(current)</span>
              </a>
            </li>
            @endif
            @include('navbar.login_dropdown')
        </div>
      </div>
      <a href="#" class="btn btn-info sidebar-mobile-toggle d-md-none mr-auto">
           <i class="fas fa-align-left"></i>
                <span></span>
        </a>
          </nav>
    

                {{-- CREATE CHANNEL --}}

                <!-- FIM CREATE CHANNEL -->
        <!---start-wrap---->
        <!---start-header---->
        
<!---//End-header---->
<!---start-content---->
    <!-- INICIO MODEL -->

        @if(Auth::check() && auth::user()->channel_name == null && session()->has('errorch'))

        <script type="text/javascript">
$(window).on('load',function(){
        $('#exampleModal').modal('show');

 });
        </script>
        <script>$(document).ready(function(){
    
$("#recipient-name").keyup(function(){
var titleval = $("#recipient-name").val();
$("#keycode").val(titleval);
});
$()

});</script>

        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <h5 class="modal-title" id="exampleModalLabel">First create your channel</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

    <form method="POST" action="{{ route('channel.store') }}">
        {{ csrf_field() }}
              @if( isset ($errors) && count($errors) > 0)
              <div class="alert alert-danger rounded">
                @foreach($errors->all() as $error)
                {{$error}}<br />
                @endforeach
              </div>
              @endif

          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Name:</label>
            <input type="text" class="form-control col-md-12" name="name" id="recipient-name" autocomplete="off" required value="{{old('name')}}" placeholder="{{auth::user()->nick}}" maxlength="25" minlength="4">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">KeyCode:</label>
            <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="fm">TibiaVines.com/</span>
                  </div>
                  <input type="text" class="form-control" id="keycode" name="keycode" autocomplete='off' required maxlength="15" minlength="4"  value="{{old('name')}}" readonly>

                </div>
          </div>
          <div class="form-group">
            <label for="rules" class="col-form-label">Terms of use-please read:</label>
            <textarea id="rules" class="form-control" rows="6" disabled>1: We only accept vines from the owner of the same.
2: Offensive or third-party names are not allowed in 'Name', 'Description', 'Thumbmail', 'Title' of the channel or vine.
3: To add a video in your channel it is necessary to have the 'Keycode' shown above in the description.
4: As of the creation of the channel you will make your 'Nick' public, and can be displayed by anyone who wants to visit your channel.
5: TibiaVines is a platform especially dedicated to Tibia, so we do not accept anything that does not have a direct relation to the game.
6: You can only enable your channel for rewards after having at least one vine with one thousand (1000) vizualizações.
7: We check IP history by channel periodically, thus not being allowed to connect to another login without authorization.
8: We will never ask for personal data for our users.
9: Never enter your account or game password in any field.
-------------
If you do not agree or do not want to follow any of these rules, please do not continue the operation.
            </textarea>
           <p class="text-danger">* By clicking 'Create Channel' you agree to the terms of use.</p>
        </div>
          
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary closemodal" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-info">Create Channel</button>
      </div>
    </form>
    </div>
  </div>
</div>
{{session()->forget('errorch')}}
@endif


@if(session()->has('back_msg'))

        <script type="text/javascript">
$(window).on('load',function(){
        $('#exampleModal').modal('show');

 });
        </script>
        <script>$(document).ready(function(){
    
$("#recipient-name").keyup(function(){
var titleval = $("#recipient-name").val();
$("#keycode").val(titleval);
});
$()

});</script>

        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <h5 class="modal-title" id="exampleModalLabel">OPS!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        {{session()->get('back_msg')}}
    </div>
  </div>
</div>
{{session()->forget('back_msg')}}
@endif

<!-- fim model  -->

<!-- FIM MODEL UPLOAD -->
<div id="main" role="main">

<div class="container">
      <div class="row">
        @include('painel.sidebar')
               <!-- /.col-lg-3 -->

        <div class="col-lg-9">

                @yield('page')
          <!-- /.card -->

        </div>
        <!-- /.col-lg-9 -->

      </div>

    </div>
    <!-- /.container -->


</div>

</div>
</div>
</div>













<!---//End-content---->
<!----wookmark-scripts---->
<script src="{{ asset('/js/jquery.imagesloaded.js') }}"></script>
<script src="{{ asset('/js/jquery.wookmark.js') }}"></script>
<script src="{{asset('/js/panel/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{asset('/js/panel/chart.js/chart.min.js') }}"></script>
<script src="{{asset('/js/carbon.js') }}"></script>
<script src="{{asset('/js/demo.js') }}"></script>



<script type="text/javascript">

$(document).ready(function() {
    
    /* Every time the window is scrolled ... */
    $(window).scroll( function(){
        /* Check the location of each desired element */
        $('li').each( function(i){
            
            var bottom_of_object = $(this).offset().top + $(this).outerHeight();
            var bottom_of_window = $(window).scrollTop() + $(window).height();
            
            /* If the object is completely visible in the window, fade it it */
            if( bottom_of_window > bottom_of_object ){
                
                $(this).animate({'opacity':'1'},500);
                    
            }
            
        }); 
    
    });
    
});


          </script>
          <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
    <script type="text/javascript">
    $(document).ready(function() {
      $("#desc").emojioneArea({

      });
    });
  </script>

<!----//wookmark-scripts---->
<!----start-footer--->
<!----//End-footer--->
<!---//End-wrap---->
</body>
</html>