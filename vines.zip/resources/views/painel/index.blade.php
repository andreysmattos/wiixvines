@extends('painel.layouts.newbase')
@section('menu')
        <div class="sidebar">
        
            <nav class="sidebar-nav" id="sidebar">
                <ul class="nav">
                    <li class="nav-title">Dashboard</li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link active">
                            <i class="fas fa-tachometer-alt"></i> Sumary
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="last-interactions" class="nav-link">
                            <i class="fab fa-angellist"></i> Latest interactions 
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="following" class="nav-link">
                            <i class="fas fa-address-book"></i> Following
                        </a>
                    </li>


                    <li class="nav-title">Channel Library</li>

                    <li class="nav-item">
                        <a href="upload-photo" class="nav-link">
                            <i class="fas fa-image"></i> Upload Photo
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="upload-vine" class="nav-link">
                            <i class="fas fa-video"></i> Upload Vines
                        </a>
                    </li>
                
                    <li class="nav-item">
                        <a href="studio" class="nav-link">
                            <i class="fas fa-tasks"></i> Studio
                        </a>
                    </li>
                   
                    <li class="nav-item">
                        <a href="vines" class="nav-link">
                            <i class="fas fa-sliders-h"></i> Vines manager
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="settings" class="nav-link disabled">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </li>                 


                 </ul>
          
               </li>



                   
                </ul>
            </nav>
        </div>
@endsection
@section('page')
<div class="row">
                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body d-flex justify-content-between align-items-center">
                                <div>

                                    <!-- PHP VIEWERS -->
                          <span class="h4 d-block font-weight-normal mb-2">                                     {{ $allviews }}
</span>

                                    <span class="font-weight-light">All viewes</span>
                                </div>

                                <div class="h2 text-muted">
                                    <i class="icon icon-people"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body d-flex justify-content-between align-items-center">
                                <div>
                                    <!-- PHP MAX VIEWER-->
                                    <span class="h4 d-block font-weight-normal mb-2">                
                                    {{$mostview}} 
                                        </span>

                                    <span class="font-weight-light">Most views in a video</span>
                                </div>

                                <div class="h2 text-muted">
                                    <i class="icon icon-wallet"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body d-flex justify-content-between align-items-center">
                                <div>
                                    
                                    <span class="h4 d-block font-weight-normal mb-2">
                                        {{$subs}}
                                    </span>
                                    
                                    <span class="font-weight-light">Subscribes</span>
                                </div>

                                <div class="h2 text-muted">
                                    <i class="icon icon-cloud-download"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <div class="card">
                            <div class="card-body d-flex justify-content-between align-items-center">
                                <div>
                                    <span class="h4 d-block font-weight-normal mb-2">
                                     {{$countvines}}
                                        
                                     </span>
                                    <span class="font-weight-light">Published vines</span>
                                </div>

                                <div class="h2 text-muted">
                                    <i class="fas fa-upload"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
          <!-- /.card -->
    <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card card-outline-secondary">
            <div class="card-header">
              Posts
            </div>
            <div class="card-body">

                @foreach($data as $value)
                                
                <div class="clearfix">
                    <a href="/{{$value->channel_name}}/{{$value->id}}">
                    @if($value->type == '0')
                    <img src="/images/uploads/{{$value->link}}" class="float-left mr-2" width="120px" height="90px" >
                    @else
                    <?php $q = explode('=', $value->link);?>
                    <img src="http://img.youtube.com/vi/{{$q[1]}}/hqdefault.jpg" class="float-left mr-2" width="120px" height="90px" >
                    @endif
              {{-- <p style="clear:both;" class="card-hearder font-weight-bold">{{$value->title}}</p> --}}
        
                <div class="content-heading"><span class="font-weight-bold">{{$value->title}}</span> 
                    @if($ditem == $value->id)
                    <i class="fas fa-star" data-toggle="tooltip" title="Default"></i>
                    @endif
                </div>
                </a>

                <span class="text-muted"><i class="far fa-eye"></i> {{$value->view}}</span>
                &nbsp;&nbsp;
                <span class="text-muted"><i class="fas fa-comment-alt"></i> {{$value->comments}}</span>
                <p></p>
    
    <div class="input-group-append ">
    <button type="button" class="btn border-dark btn-outline-secondary" onclick="window.location.href='edit/{{$value->id}}'">Edit</button>
    <button type="button" class="btn btn-outline-dark dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <span class="sr-only">Toggle Dropdown</span>
    </button>   
    <div class="dropdown-menu">
      <a class="dropdown-item" href="/{{$value->channel_name}}/{{$value->id}}" target="_blank">Watch</a>    
      
       <form action="{{route('setDefault')}}" method="POST">
        {{csrf_field()}}
      <input type="hidden" value="{{$value->id}}" name="id">
      <button type="submit" class="dropdown-item btn border-0">Set Default</button>
      </form>
      

      <a class="dropdown-item" href="#">Promoted</a>
      <div role="separator" class="dropdown-divider"></div>


      <form action="{{route('deleteVine')}}" method="POST">
        {{csrf_field()}}
      <input type="hidden" value="{{$value->id}}" name="id">
      <button type="submit" class="dropdown-item btn border-0" onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>
      </form>


    </div>
  </div>
 

      
      <div style="clear:both"></div>

              </div>
                
                <?php 
                $timeStamp = $value->created_at;
                $timeStamp = date( "d M Y H:m", strtotime($timeStamp));
?>
              <small class="text-muted">Posted on {{$timeStamp}}</small>
              <hr>
                @endforeach

                <a href="vines"><p class="text-center text-primary font-weight-bold">See all</p></a>
            </div>
          </div>
</div>
        <div class="col-md-4">
                        <div class="card">
            
            <div class="card-header border-bottom">
              Notifications
            </div>
            <div class="card-body" id="fast-interaction">
                Loading...
                </div>

                <div class="card-footer"><a href="last-interactions"><p class="text-center text-primary font-weight-bold">See all</p></a></div>
                

            


        </div>
</div>


@endsection