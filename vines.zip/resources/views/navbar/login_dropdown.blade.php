 @if (Auth::check())

           {{--  <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                             <i class="fa fa-bell text-danger"></i> 0
                          </a>
                          <div class="dropdown-menu dropdown-menu-right">
                            <a href="#" class="dropdown-item">
                                Nothing new..
                              </a>
                            </div>

                          </li> --}}

          <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                {{ Auth::user()->nick }}
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a href="/user/control-panel" class="dropdown-item">
                                    <i class="pr-2 fas fa-tachometer-alt"></i> Dashboard
                                </a>
                                <div class="dropdown-header bg-light text-center">Channel</div>
                                @if(auth::user()->channel_name != null)
                                <a href="/{{auth::user()->channel_name}}" class="dropdown-item">
                                    <i class="fas fa-images"></i> My Channel
                                </a>
                                @else
                                <a href="/user/create-channel" class="dropdown-item">
                                    <i class="fas fa-images"></i> Create Channel
                                </a>
                                @endif
                                
                                <a href="/user/upload-photo" class="dropdown-item">
                                    <i class="pr-2 fas fa-cloud-upload-alt"></i>Upload Photo
                                </a>

                                <a href="/user/upload-vine" class="dropdown-item">
                                    <i class="pr-2 fas fa-cloud-upload-alt"></i>Upload Vine
                                </a>
                                <a href="/user/vines" class="dropdown-item">
                                    <i class="pr-2 far fa-file-video"></i> Vine management
                                </a>
                                <a href="/user/studio" class="dropdown-item">
                                    <i class="pr-2 fas fa-cog"></i> Channel studio
                                </a>
                                <div class="dropdown-header bg-light text-center">Perfil</div>
                                <a href="/user/settings" class="dropdown-item">
                                    <i class="pr-2 fa fa-wrench"></i> Personal Settings
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="{{ route('logout') }}" onclick="event.preventDefault();  document.getElementById('logout-form').submit();" class="dropdown-item">
                                    <i class="pr-2 fa fa-lock"></i> Logout
                                </a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                    {{ csrf_field() }}
                                </form>
                            </div>
                        </li>
            @else
 <ul class="nav navbar-nav flex-row justify-content-between ml-auto">
                
                <li class="dropdown order-1">
                    <button type="button" id="dropdownMenu1" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">Login <span class="caret"></span></button>
                    <ul class="dropdown-menu dropdown-menu-right mt-2">
                       <li class="px-3 py-2">
                           <form class="form" role="form" method="POST" action="{{route('login')}}">
                            {{csrf_field()}}
                                <div class="form-group">
                                    <input id="emailInput" name="email" placeholder="Email" class="form-control form-control-sm" type="text" required>
                                    @if ($errors->has('email'))                                  
                                        <small class="text-danger">{{ $errors->first('email') }}</small>
                                    
                                    @endif
                                </div>
                                <div class="form-group">
                                    <input id="passwordInput" name="password" placeholder="Password" class="form-control form-control-sm" type="password" required>
                                    @if ($errors->has('password'))
                                 <small class="text-danger">{{ $errors->first('password') }}</small>
                                    
                                @endif
                                </div>
                                
                                <div class="form-group">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Remember Me
                                    </label>
                                </div>
                                    <button type="submit" class="btn btn-info btn-block">Login</button>
                                    
                                </div>
                                <div class="form-group text-center">
                                    <small><a href="{{ route('password.request') }}" class="btn btn-link">Forgot password?</a></small>
                                </div>
                            </form>
                        </li>
                    </ul>
            <li class="nav-item">
              <a class="nav-link" href="{{route('register')}}">Register</a>
            </li>

            @endif

      
          </ul>