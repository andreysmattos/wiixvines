<?php $__env->startSection('menu'); ?>
        <div class="sidebar">
        
            <nav class="sidebar-nav" id="sidebar">
                <ul class="nav">
                    <li class="nav-title">Dashboard</li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link ">
                            <i class="fas fa-tachometer-alt"></i> Sumary
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="last-interactions" class="nav-link">
                            <i class="fab fa-angellist"></i> Latest interactions 
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="following" class="nav-link active">
                            <i class="fas fa-address-book"></i> Following
                        </a>
                    </li>


                    <li class="nav-title">Channel Library</li>

                    <li class="nav-item">
                        <a href="upload-photo" class="nav-link">
                            <i class="fas fa-image"></i> Upload Photo
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="upload-vine" class="nav-link">
                            <i class="fas fa-video"></i> Upload Vines
                        </a>
                    </li>
                
                    <li class="nav-item">
                        <a href="studio" class="nav-link" disabled>
                            <i class="fas fa-tasks"></i> Studio
                        </a>
                    </li>
                   
                    <li class="nav-item">
                        <a href="vines" class="nav-link">
                            <i class="fas fa-sliders-h"></i> Vines manager
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link disabled">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </li>                 


                 </ul>
          
               </li>



                   
                </ul>
            </nav>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
<div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">

                  <div class="card mb-3 text-left" style="width: 100%;height:100%">
  <div class="card-header bg-light">Following</div>
  <div class="card-body">
 <?php $__empty_1 = true; $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <a href="/<?php echo e($sub->name); ?>">
    <div class="clearfix">
     <img src="/images/user_lv1.png" class="float-left mr-2 rounded-circle" width="32" height="32" >
    <h5 class="card-title font-weight-bold "><?php echo e($sub->name); ?> <small class="text-muted">since <?php echo e(Carbon\Carbon::parse($sub->created_at)->format('d M Y')); ?></small></h5>
      </div>
      </a>
      
        <form action="<?php echo e(route('unsubscribe')); ?>" method='POST'>
        <?php echo e(csrf_field()); ?>

          <input type="hidden" value="<?php echo e($sub->name); ?>" name="name">
          <button class="btn btn-secondary" type="submit"><i class="fas fa-user-times"></i> 
          unfollow</button>
        </form>

    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
We search some channels to you follow... <a href="/">check here!</a>
<?php endif; ?>

  </div>
  <div class="card-footer bg-transparent">
  </div>
</div>

      </div>


                </div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.layouts.newbase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>