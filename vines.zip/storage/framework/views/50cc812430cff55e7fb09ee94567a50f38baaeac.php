<?php $__env->startSection('feed_vines'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('loop_vines'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul id="tiles">
	<li>
		<a href="/watch?v=<?php echo e($value->id); ?>">
			<?php $q = explode('=', $value->link);

?>
			<img src="http://img.youtube.com/vi/<?php echo e($q[1]); ?>/hqdefault.jpg" >
			<div class="post-info">
				<div class="post-basic-info">
					<h3><a href="/watch?v=<?php echo e($value->id); ?>" class="text-info font-weight-normal"><?php echo e($value->title); ?></a></h3>
					<span><a href="/watch?v=<?php echo e($value->id); ?>" class="text-dark text-capitalize"><i class="fas fa-globe-americas"></i> <?php echo e($value->server); ?></a></span>
					<p class="font-weight-normal"><?php echo e($value->description); ?></p>
				</div>
			</a>
			<div class="post-info-rate-share">
				<div class="rateit">
					<?php echo e($value->view); ?> views
				</div>
				<a href="/<?php echo e($value->channel_name); ?>">
				<div class="post-share">
					<span class="text-capitalize">
						<i class="fas fa-book"></i> <?php echo e($value->channel_name); ?>

					</span>
				</div>
			</a>
				<div class="clear"> </div>
			</div>
		</div>
	</li>
</ul>



	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>