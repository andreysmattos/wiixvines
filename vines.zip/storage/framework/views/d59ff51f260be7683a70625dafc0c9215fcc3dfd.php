<?php $__env->startSection('title', 'Create Channel'); ?>
<?php $__env->startSection('channel_menu', 'active'); ?>


<?php $__env->startSection('col-padrao', 'col-lg-12'); ?>

<?php $__env->startSection('feed_vines'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('loop_vines'); ?>
<div class="col-md-12 rounded py-3 text-left justify-content-center d-flex" id="post-data"> 
<script>$(document).ready(function(){
    
$("#recipient-name").keyup(function(){
var titleval = $("#recipient-name").val();
$("#keycode").val(titleval);
});
$()

});</script>
<!--inicio do modal -->
                        <div class="card col-md-10">
                            <div class="card-header bg-light">
                                Create Channel
                            </div>
                            <div class="card-body">
    
                                <div class="row">

                                    <div class="col-md-12" align="left">

    <form method="POST" action="<?php echo e(route('channel.store')); ?>">
        <?php echo e(csrf_field()); ?>

              <?php if( isset ($errors) && count($errors) > 0): ?>
              <div class="alert alert-danger rounded">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>

          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Name:</label>
            <input type="text" class="form-control col-md-12" name="name" id="recipient-name" autocomplete="off" required value="<?php echo e(old('name')); ?>" placeholder="<?php echo e(auth::user()->nick); ?>" maxlength="25" minlength="4">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">KeyCode:</label>
            <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="fm">TibiaVines.com/</span>
                  </div>
                  <input type="text" class="form-control" id="keycode" name="keycode" autocomplete='off' required maxlength="15" minlength="4"  value="<?php echo e(old('name')); ?>" readonly>

                </div>
          </div>
          <div class="form-group">
            <label for="rules" class="col-form-label">Terms of use:</label>
            <textarea id="rules" class="form-control" rows="16" disabled>1: We only accept vines from the owner of the same.
2: Offensive or third-party names are not allowed in 'Name', 'Description', 'Thumbmail', 'Title' of the channel or vine.
3: To add a video in your channel it is necessary to have the 'Keycode' shown above in the description.
4: As of the creation of the channel you will make your 'Nick' public, and can be displayed by anyone who wants to visit your channel.
5: TibiaVines is a platform especially dedicated to Tibia, so we do not accept anything that does not have a direct relation to the game.
6: You can only enable your channel for rewards after having at least one vine with one thousand (1000) vizualizações.
7: We check IP history by channel periodically, thus not being allowed to connect to another login without authorization.
8: We will never ask for personal data for our users.
9: Never enter your account or game password in any field.
-------------
If you do not agree or do not want to follow any of these rules, please do not continue the operation.
            </textarea>
           <p class="text-danger">* By clicking 'Create Channel' you agree to the terms of use.</p>
        </div>
          
        
      
        <a href="/">
        <button type="button" class="btn btn-secondary closemodal" data-dismiss="modal">Back</button></a>
        <div class="float-right form-group">
        <button type="submit" class="btn btn-info">Create Channel</button>
        </div>
      </div>
    </form>
    </div>
  </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_channel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>