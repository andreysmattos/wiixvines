<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/fav-icon.png')); ?>" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <script
        src="https://code.jquery.com/jquery-3.3.1.js"
        integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
        crossorigin="anonymous"></script>
        <link href="<?php echo e(asset('/js/panel/simple-line-icons/css/simple-line-icons.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('/js/panel/font-awesome/css/fontawesome-all.min.css')); ?>" rel="stylesheet">         

        <link href="<?php echo e(asset('/css/styles-auth.css')); ?>" rel="stylesheet">
        <!-- scripts -->

</head>
<body class="sidebar-fixed header-fixed">
<div class="page-wrapper">
    <nav class="navbar page-header">
        <a href="#" class="btn btn-link sidebar-mobile-toggle d-md-none mr-auto">
            <i class="fa fa-bars"></i>
        </a>

        <a class="navbar-brand" href="/">
            <img src="<?php echo e(asset('/images/logo.png')); ?>" alt="logo">
        </a>

        <a href="#" class="btn btn-link sidebar-toggle d-md-down-none">
            <i class="fa fa-bars"></i>
        </a>

       <ul class="navbar-nav ml-auto">
           <!--  <li class="nav-item d-md-down-none">
                <a href="#">
                    <i class="fa fa-bell"></i>
                    <span class="badge badge-pill badge-danger">5</span>
                </a>
            </li>

            <li class="nav-item d-md-down-none">
                <a href="#">
                    <i class="fa fa-envelope-open"></i>
                    <span class="badge badge-pill badge-danger">5</span>
                </a>
            </li> -->

<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <img src="<?php echo e(asset('/images/user_lv1.png')); ?>" class="avatar avatar-sm" alt="logo">
                                <span class="small ml-1 d-md-down-none"><?php echo e(Auth::user()->nick); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a href="/user/control-panel" class="dropdown-item">
                                    <i class="pr-2 fas fa-tachometer-alt"></i> Dashboard
                                </a>
                                <div class="dropdown-header bg-light text-center">Channel</div>
                                <a href="/user/upload" class="dropdown-item">
                                    <i class="pr-2 fas fa-cloud-upload-alt"></i>Upload Vine
                                </a>
                                <a href="/user/vines" class="dropdown-item">
                                    <i class="pr-2 far fa-file-video"></i> Vine management
                                </a>
                                <a href="#" class="dropdown-item disabled">
                                    <i class="pr-2 fas fa-cog"></i> Settings
                                </a>
                                <div class="dropdown-header bg-light text-center">Perfil</div>
                                <a href="#" class="dropdown-item disabled">
                                    <i class="pr-2 fa fa-wrench"></i> Personal Settings
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();  document.getElementById('logout-form').submit();" class="dropdown-item">
                                    <i class="pr-2 fa fa-lock"></i> Logout
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </div>
                        </li>
    </ul>
    </nav>

    <div class="main-container">
<?php echo $__env->yieldContent('painel-menu'); ?>
        <div class="content">
            <div class="container-fluid">
          
            <?php echo $__env->yieldContent('content'); ?>



          </div>    
    </div>
</div>
<script src="<?php echo e(asset('/js/panel/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/panel/popper.js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/panel/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/panel/chart.js/chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/carbon.js')); ?>"></script>
<script src="<?php echo e(asset('/js/demo.js')); ?>"></script>

</body>
</html>
