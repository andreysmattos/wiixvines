<?php $__env->startSection('posts_menu', 'active'); ?>
<?php $__env->startSection('col-padrao', 'col-lg-9'); ?>

<?php $__env->startSection('search_att'); ?>
<form action='' method="POST">
            <div class="form-group">
            <h4><strong>
              Search</strong>
            </h4>
            <input type="text" class="form-control" id="searchAll" placeholder="Title / Channel name">
      </div>
        <hr>
      <div class="form-group">
            <h4><b>
              Gameworld</b>
            </h4>
            <select name="world" class="form-control" id="servers">
              <option value="all">All worlds</option>
               <?php $__currentLoopData = $worlds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($value->server); ?>"><?php echo e($value->server); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>

            </div>
        <hr>
            <div class="form-group" id="pvptype">
            <h4><b>
              PvP Type</b>
            </h4>

     <div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" id="allpvp" name="pvptype" value="all" checked>
  <label class="custom-control-label" for="allpvp">All</label>
</div>

     <div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="openpvp" value="Open PvP">
  <label class="custom-control-label" for="openpvp">Open PvP</label>
</div>

    <div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="optinal" value="Optional PvP">
  <label class="custom-control-label" for="optinal">Optional PvP</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="retroopen" value="Retro Open PvP">
  <label class="custom-control-label" for="retroopen">Retro Open PvP</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="retrohardcore" value="Retro Hardcore PvP">
  <label class="custom-control-label" for="retrohardcore">Retro Hardcore PvP</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" class="custom-control-input" name="pvptype" id="hardcorepvp" value="Hardcore PvP">
  <label class="custom-control-label" for="hardcorepvp">Hardcore PvP</label>
</div>




            </div>
  <hr>
            <div class="form-group" id="radioplaymode">
            <h4><b>
              Play Mode</b>
            </h4>
<div class="custom-control custom-checkbox">
  <input type="radio" name="playmode" value="all" class="custom-control-input" id="allradio" value="all" checked>
  <label class="custom-control-label" for="allradio">All</label>
</div> 

            <div class="custom-control custom-checkbox">
  <input type="radio" name="playmode" value="pvp" class="custom-control-input" id="Player vs Player">
  <label class="custom-control-label" for="Player vs Player">Player vs Player</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" name="playmode" value="pvm" class="custom-control-input" id="Player vs MoB">
  <label class="custom-control-label" for="Player vs MoB">Player vs MoB</label>
</div>

<div class="custom-control custom-checkbox">
  <input type="radio" name="playmode" value="quests" class="custom-control-input" id="Quests">
  <label class="custom-control-label" for="Quests">Quests</label>
</div>

            </div>

</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('findmode'); ?>
  <div class="form-row align-items-center">
    <div class="col-auto my-1">
      <select class="form-control form-control-lg" id="preferences">
        <option value="recent" selected>Most recent</option>
        <option value="viewed">Most viewed</option>
      </select>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('loop_vines'); ?>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-lg-3 col-md-5" style="padding:0 5px 0 0;">
              <div class="card rounded border-0 bg-transparent">
                <?php if($value->type=='0'): ?>
                  <?php $img = "<i class='fas fa-image'></i>"; ?>
                <?php else: ?>
                  <?php $img = "<i class='fas fa-video'></i>"; ?>
                <?php endif; ?>
                  <?php if($value->type == '0'): ?>
                  <a href="<?php echo e($value->channel_name); ?>/<?php echo e($value->id); ?>">
                <img class="lazy-fade card-img-top img-responsive" src="/images/default.jpg" data-src="/images/uploads/<?php echo e($value->link); ?>" alt="" style="max-width: 100%;height: auto;width:210px;height:118px;"></a>
                  <?php else: ?>
                <?php $q = explode('=', $value->link);?>
                <a href="<?php echo e($value->channel_name); ?>/<?php echo e($value->id); ?>"><img src="/images/default.jpg" class="lazy-fade card-img-top img-responsive" data-src="http://img.youtube.com/vi/<?php echo e($q[1]); ?>/hqdefault.jpg" style="max-width: 100%;height: auto;width:210px;height:118px;"></a>
              
                <?php endif; ?>

                <div class="card-body">
                  <span class="card-title font-weight-bold">
                    <a href="<?php echo e($value->channel_name); ?>/<?php echo e($value->id); ?>"><?= $img ?> <?php echo e($value->title); ?></a>
                  </span>
                  <div class="clearfix"></div>                
                  <small class="text-muted"><i class="fas fa-globe-americas"></i> <?php echo e($value->server); ?></small>
                  <div class="clearfix"></div>
                  <a href="/<?php echo e($value->channel_name); ?>" class="hover-href"><small class=""><i class="fas fa-book"></i> <?php echo e($value->channel_name); ?></small></a>
                  <div class="clearfix">
                  <small class="text-muted"><i class="far fa-eye"></i> <?php echo e($value->view); ?></small>
                  <div class="clearfix"></div>
                  <small class="text-muted">  <?php echo e(Carbon\Carbon::parse($value->created_at)->diffForHumans()); ?></small>
                  </div>

                                    
                 </div>

              </div>
            </div>
 

  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div class="row bg-light col-12">
    <?php echo e($data->render("pagination::bootstrap-4")); ?>

  </div>

    <?php $__env->stopSection(); ?>  
  

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>