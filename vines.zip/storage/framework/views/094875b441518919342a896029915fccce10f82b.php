<?php $__env->startSection('title'); ?>
<title>TibiaVines - Register</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="row justify-content-center">
    <div class="col-md-5">
        <div class="card p-4">
            <div class="d-flex justify-content-center">
                <a href="/"><img src="<?php echo e(asset('/images/logo.png')); ?>" title="TibiaVines" /></a>
            </div>
            
            <div class="text-center text-uppercase h4 font-weight-light">
                Register
            </div>
            <div class="bg-info text-light font-weight-light text-center rounded pt-2 pb-2" class="erroinsert" id="msgerro">              
            </div>

                <div class="card-body py-3">
                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo e(csrf_field()); ?>

                        
                        <div class="form-group<?php echo e($errors->has('nick') ? ' has-error' : ''); ?>">
                            <label for="nick">Nick</label>

                            
                                <input id="nick" type="text" class="form-control" name="nick" value="<?php echo e(old('nick')); ?>" required autofocus>

                                <?php if($errors->has('nick')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('nick')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>                                              

                        <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                            <label for="email" >E-Mail Address</label>

                            
                         <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>

                        <div class="form-group<?php echo e($errors->has('login') ? ' has-error' : ''); ?>">
                            <label for="name">Login</label>

                            
                                <input id="name" type="text" class="form-control" name="login" value="<?php echo e(old('login')); ?>" required autofocus>

                                <?php if($errors->has('login')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('login')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>  
                        
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label for="password">Password</label>

                            
                                <input id="password" type="password" class="form-control" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>

                        <div class="form-group">
                            <label for="password-confirm">Confirm Password</label>

                            
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-info">
                                    Register
                                </button>
                            </div>
                        </div>
                        <div class="card-footer">
                        <span>Already have an account?<a href="<?php echo e(route('login')); ?>"> Sign in<a></span>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>