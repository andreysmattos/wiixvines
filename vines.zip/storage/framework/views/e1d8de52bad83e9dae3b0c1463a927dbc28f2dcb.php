<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>">
	<head>
		<title>TibiaVines - Feed</title>
		<link href="css/style.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/x-icon" href="/images/fav-icon.png" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		</script>
		<!----webfonts---->
		<script
		src="https://code.jquery.com/jquery-3.3.1.js"
		integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
		crossorigin="anonymous"></script>
		<!----//webfonts---->

		<!-- Global CSS for the page and tiles -->
		<link href="<?php echo e(asset('/css/main.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('/css/all.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('/font-awesome/css/all.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('/css/styles-auth.css')); ?>" rel="stylesheet">
		<!-- scripts -->
		<script src="<?php echo e(asset('/js/bootstrap.bundle.js')); ?>"></script>
    <script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery.lazy/1.7.4/jquery.lazy.min.js"></script>
    <script src="/jquery.lazy-master/jquery.lazy.js"></script>
<script>
  $(function(){
  $("img.lazy-fade").lazy();
});

</script>

    <script src="https://unpkg.com/masonry-layout@4.2.2/dist/masonry.pkgd.min.js"></script>
<style>
  .masonry-column {
  padding: 0 1px;
}

.masonry-grid > div .thumbnail {
  margin: 5px 1px;
}

</style>

 <script type="text/javascript">
  $(document).ready(function(){

     $('#searchAll').keyup(function(){
      $value=$(this).val();
 
$.ajax({
 
type : 'get',
 
url : '<?php echo e(route('searchAll')); ?>',
 
data:{'search':$value},
 
success:function(data){
 
$('#loopvines').html(data);
 
}
 
});
});


  $('#servers').change(function(){
      $value=$(this).val();
 
$.ajax({
 
type : 'get',
 
url : '<?php echo e(route('searchSv')); ?>',
 
data:{'search':$value},
 
success:function(data){
 
$('#loopvines').html(data);
 
}
 
});
 


  });


    $('#preferences').change(function(){
      $value=$(this).val();
 
$.ajax({
 
type : 'get',
 
url : '<?php echo e(route('preferences')); ?>',
 
data:{'search':$value},
 
success:function(data){
 
$('#loopvines').html(data);
 
}
 
});
 


  });


});


</script>
<script> 
    $(document).ready(function(){
  $('#radioplaymode input[name=playmode]').click(function(){

        $value=$(this).val();
 
$.ajax({
 
type : 'get',
 
url : '<?php echo e(route('searchMode')); ?>',
 
data:{'search':$value},
 
success:function(data){
 
$('#loopvines').html(data);
 
}
 
});

});
 
    $('#pvptype input[name=pvptype]').click(function(){

        $value=$(this).val();
 
$.ajax({
 
type : 'get',
 
url : '<?php echo e(route('searchType')); ?>',
 
data:{'search':$value},
 
success:function(data){
 
$('#loopvines').html(data);
 
}
 
});

});

 });

</script>
<script type="text/javascript">
 
$.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
 
</script>
	</head>
	<body>
    <div class="page-wrapper <?php echo $__env->yieldContent('bg_color'); ?>">
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" style="-webkit-box-shadow: 0px 5px 5px 0px rgba(0,0,0,0.75);
-moz-box-shadow: 0px 5px 5px 0px rgba(0,0,0,0.75);
box-shadow: 0px 5px 5px 0px rgba(0,0,0,0.75);">
      <div class="container">
        <a class="navbar-brand" href="/"><img src="/images/logo.png" alt="TibiaVines" height="40"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link <?php echo $__env->yieldContent('posts_menu'); ?>" href="/">Posts
                <span class="sr-only">(current)</span>
              </a>
            </li> 
            <li class="nav-item <?php echo $__env->yieldContent('channel_menu'); ?>">
              <a class="nav-link" href="/channels">Channels
                <span class="sr-only">(current)</span>
              </a>
            </li>            
            <?php if(auth::check()): ?>
            <li class="nav-item <?php echo $__env->yieldContent('feed_menu'); ?>">
              <a class="nav-link" href="/feed">Feed
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
              <a class="nav-link" href="#"></a>
            </li>
            <hr>   
            <?php echo $__env->make('navbar.login_dropdown', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      </div>
    </nav>
				

				<!-- FIM CREATE CHANNEL -->
		<!---start-wrap---->
		<!---start-header---->
		
<!---//End-header---->
<!---start-content---->
	<!-- INICIO MODEL -->

		<?php if(Auth::check() && auth::user()->channel_name == null && (session()->has('errorch') || (isset ($errors) && count($errors) > 0))): ?>

		<script type="text/javascript">
$(window).on('load',function(){
        $('#exampleModal').modal('show');

 });
		</script>
		<script>$(document).ready(function(){
    
$("#recipient-name").keyup(function(){
var titleval = $("#recipient-name").val();
$("#keycode").val(titleval);
});
$()

});</script>

		<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <h5 class="modal-title" id="exampleModalLabel">First create your channel</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

    <form method="POST" action="<?php echo e(route('channel.store')); ?>">
        <?php echo e(csrf_field()); ?>


              <?php if( isset ($errors) && count($errors) > 0): ?>
              <div class="alert alert-danger rounded">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>

          <div class="form-group">
            <label for="recipient-name" class="col-form-label <?php echo e($errors->has('name') ? 'text-danger' : ''); ?>">Name:</label>
            <input type="text" class="form-control col-md-12" name="name" id="recipient-name" autocomplete="off" required placeholder="<?php echo e(auth::user()->nick); ?>" maxlength="25" minlength="4">
                                
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">KeyCode:<?php echo e($errors->has('keycode') ? ' has-error' : ''); ?></label>
            <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="fm">TibiaVines.com/</span>
                  </div>
                  <input type="text" class="form-control" id="keycode" name="keycode" autocomplete='off' required maxlength="15" minlength="4" readonly>

                </div>
          </div>
          <div class="form-group">
            <label for="rules" class="col-form-label">Terms of use-please read:</label>
            <textarea id="rules" class="form-control" rows="6" disabled>1: We only accept vines from the owner of the same.
2: Offensive or third-party names are not allowed in 'Name', 'Description', 'Thumbmail', 'Title' of the channel or vine.
3: To add a video in your channel it is necessary to have the 'Keycode' shown above in the description.
4: As of the creation of the channel you will make your 'Nick' public, and can be displayed by anyone who wants to visit your channel.
5: TibiaVines is a platform especially dedicated to Tibia, so we do not accept anything that does not have a direct relation to the game.
6: You can only enable your channel for rewards after having at least one vine with one thousand (1000) vizualizações.
7: We check IP history by channel periodically, thus not being allowed to connect to another login without authorization.
8: We will never ask for personal data for our users.
9: Never enter your account or game password in any field.
-------------
If you do not agree or do not want to follow any of these rules, please do not continue the operation.
            </textarea>
           <p class="text-danger">* By clicking 'Create Channel' you agree to the terms of use.</p>
        </div>
          
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary closemodal" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-info">Create Channel</button>
      </div>
    </form>
    </div>
  </div>
</div>
<?php echo e(session()->forget('errorch')); ?>

<?php endif; ?>


<?php if(session()->has('back_msg')): ?>

		<script type="text/javascript">
$(window).on('load',function(){
        $('#exampleModal').modal('show');

 });
		</script>
		<script>$(document).ready(function(){
    
$("#recipient-name").keyup(function(){
var titleval = $("#recipient-name").val();
$("#keycode").val(titleval);
});
$()

});</script>

		<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <h5 class="modal-title" id="exampleModalLabel">Huh...</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

    	<?php echo e(session()->get('back_msg')); ?>

    </div>
  </div>
</div>
</div>
<?php echo e(session()->forget('back_msg')); ?>

<?php endif; ?>

<!-- fim model  -->

		

<!-- FIM MODEL UPLOAD -->




		<div id="main" role="main">

 <div class="<?php echo $__env->yieldContent('ch_color'); ?> container pl-5 pr-5 rounded">

      <div class="row">

       <div class="<?php echo $__env->yieldContent('col-padrao'); ?>">

          
				<h3><b><?php echo $__env->yieldContent('findmode'); ?></b></h3>
          <div class="row" id="loopvines">
			<?php echo $__env->yieldContent('loop_vines'); ?>
            
          </div>
          <!-- /.row -->

        </div>
        <!-- /.col-lg-9 -->
<div class="col-lg-3" >
  <?php echo $__env->yieldContent('search_att'); ?>


      </div>

        </div>
        <!-- /.col-lg-3 -->
      </div>
      <!-- /.row -->

    </div>
    <!-- /.container -->


</div>




<?php echo $__env->yieldContent('footer'); ?>


</div>









<!---//End-content---->
<!----wookmark-scripts---->
<script src="<?php echo e(asset('/js/jquery.imagesloaded.js')); ?>"></script>
<script src="<?php echo e(asset('/js/jquery.wookmark.js')); ?>"></script>

<script type="text/javascript">

$(document).ready(function() {
    
    /* Every time the window is scrolled ... */
    $(window).scroll( function(){
        /* Check the location of each desired element */
        $('li').each( function(i){
            
            var bottom_of_object = $(this).offset().top + $(this).outerHeight();
            var bottom_of_window = $(window).scrollTop() + $(window).height();
            
            /* If the object is completely visible in the window, fade it it */
            if( bottom_of_window > bottom_of_object ){
                
                $(this).animate({'opacity':'1'},500);
                    
            }
            
        }); 
    
    });
    
});


		  </script>
         
<!----//wookmark-scripts---->
<!----start-footer--->
<!----//End-footer--->
<!---//End-wrap---->
</body>
</html>