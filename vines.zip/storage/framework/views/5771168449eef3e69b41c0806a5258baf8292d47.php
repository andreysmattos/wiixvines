<?php $__env->startSection('feed_menu', 'active'); ?>
<?php $__env->startSection('feed'); ?>

          <!-- Blog Entries Column -->
<div class="col-md-8 rounded py-3 text-left bg-light border ml-2 mb-2 text-center">

    <a href="/user/upload-photo" target="_blank" >
    <button type="button" class="btn btn-light col-md-3">
    <div class="photo"></div>
    <div class="clearfix"></div>
    <small>Upload</small>
    <small>Photo</small>    
    </button>
    </a>

    <a href="/user/upload-vine" target="_blank">
    <button type="button" class="btn btn-light col-md-3">
    <div class="video"></div>
    <div class="clearfix"></div>
    <small>Upload Video</small>    
    </button>
    </a>


    <a href="/<?php echo e(auth::user()->channel_name); ?>" target="_blank">
    <button type="button" class="btn btn-light col-md-3">
    <div class="channel"></div>
    <div class="clearfix"></div>
    <small>My channel</small>    
    </button>
    </a>
    

  
  
</div>
        <div class="col-md-8 rounded py-3 text-left bg-white border ml-2" id="post-data">          
          <?php echo $__env->make('data', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="ajax-load text-center" style="display:none">
  <p><img src="https://demo.itsolutionstuff.com/plugin/loader.gif">Loading More post</p>
</div>
        </div>
        
        <script>
          var imgs = $(".tibiavines-images-load");
    $.each(imgs, function () {
        var $this = $(this);
        var im = new Image();
        im.onload = function () {
            var theImage = $this;
            $this.hide("slow");
            theImage[0].src = im.src;
            $this.show('fast');
        };
        im.src = $this.data("mainsrc");
    });

        </script>
  	<?php $__env->stopSection(); ?>  

    <?php $__env->startSection('widgets'); ?>
    <?php if(count($widgets)> 0): ?>
    <div class="card border bg-light rounded mb-3 text-left" style="max-width: 18rem;">

  <h5 class="card-header rounded-top">Others channels</h5>
  <div class="card-body">
    
    <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="/<?php echo e($widget->name); ?>">
    <div class="clearfix">
      <?php if($widget->image): ?>
      <img data-src="/images/profile-images/<?php echo e($widget->image); ?>" class="lazy-none float-left mr-2 rounded-circle" width="32" height="32" >
      <?php else: ?>
     <img data-src="/images/profile-images/default.png" class="lazy-none float-left mr-2 rounded-circle" width="32" height="32" >
      <?php endif; ?>

    <h5 class="card-title font-weight-bold "><?php echo e($widget->name); ?></h5>
      </div>
      </a>  
            <form action="<?php echo e(route('subscribe')); ?>" method='POST'>
        <?php echo e(csrf_field()); ?>

        <input type="hidden" value="<?php echo e($widget->name); ?>" name="name">
        <button type="submit" class="btn btn-outline-secondary"><i class='fas fa-check'></i> Follow </button>
      </form>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php endif; ?>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.feed_master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>