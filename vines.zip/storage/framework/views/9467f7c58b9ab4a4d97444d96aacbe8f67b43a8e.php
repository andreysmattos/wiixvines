<?php $__env->startSection('feed_vines'); ?>
    <div class="input-group col-sm-10 col-md-8 container mb-2" id="buscar-container">
			<input type="text" class="form-control" placeholder="Estou procurando por..." aria-label="Recipient's username" aria-describedby="basic-addon2">
			<div class="input-group-append">
				<button class="btn btn-outline-info" type="button">Procurar</button>
			</div>
		</div>
		
		<form class="form-inline d-flex justify-content-center bg-light pt-2 mb-2" action="" method="POST">
			<div class="form-group mb-2">
				<label for="pvptype" class="pl-1">PvP Type:</label>
				<select class="custom-select" id="pvptype" name="pvptype">
					<option value=""></option>
				</select>
			</div>
			<div class="form-group mb-2">
				<label for="worldtype" class="pl-1">Server:</label>
				<select class="custom-select" id="worldtype" name="world">
					
				</select>
			</div>
			<div class="form-group mb-2">
				<label for="modetype" class="pl-1">Modo de Jogo:</label>
				<select class="custom-select" id="modetype" name="mode">
					<option value="All" selected>All</option>
					<option value="0">PvP</option>
					<option value="1">PvE</option>
					<option value="2">Quests</option>
				</select>
			</div>
		</form>
		<!-- These are our grid blocks -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('loop_vines'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<a href="watch.php?v=<?= $rows['id'] ?>">
			        <li>
			        	<img src="http://img.youtube.com/vi/<?php echo e($value->link); ?>/hqdefault.jpg" >
			        	<div class="post-info">
			        		<div class="post-basic-info">
				        		<h3><a href="#" class="text-info font-weight-normal"><?php echo e($value->title); ?>></a></h3>

				        		<span><a href="#" class="text-dark text-capitalize"><i class="fas fa-globe-americas"></i><?php echo e($value->world); ?></a></span>
				        		<p class="font-weight-normal"><?php echo e($value->desc); ?></p>
			        		</div>

			        		<div class="post-info-rate-share">		        			
			        				<div class="rateit">
			        						<i class="ml-2 fas fa-eye"></i> {{-- <?= $view['totalvisit']; ?> --}}
			        				</div></a>
			        				<div class="post-share">     			        	
			        				<span class="text-capitalize">
			        					<img src="images/wiix.png" alt="" class="rounded-circle bg-info mt-1 btn-outline-info" width="10"><?php echo e($value->channel); ?>

			        				</span>
			        			</div>
			        			<div class="clear"> </div>
			        		</div>
			        	</div>
			        </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>