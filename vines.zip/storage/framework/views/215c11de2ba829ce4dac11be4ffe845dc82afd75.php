<?php $__env->startSection('col-padrao', 'col-lg-12'); ?>
<?php $__env->startSection('bg_color', ''); ?>
<?php $__env->startSection('ch_color', 'bg-white rounded border'); ?>
<?php 
$bg_header = "bg-dark";
$ch_name_color = "text-light";
$ch_desc_color = "text-light";

$title_color = "";
$subtitle_color = "text-muted";

$text_color = "text-light";
$hr_color ="bg-light";

?>


<?php $__env->startSection('feed_vines'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('loop_vines'); ?>

<section class="bg-white col-md-12 mb-3"  align="center" style="height:256px;">
<a href="/<?php echo e($name); ?>">
    <?php if($profileimage): ?>
    <img src="/images/default.jpg" data-src="/images/profile-images/<?php echo e($profileimage); ?>" class="rounded-circle lazy ml-2 col-md-2 img-responsive mt-0" width="128px" height="128px" alt="">
    <?php else: ?>
    <img src="/images/default.jpg" data-src="/images/profile-images/default.png" class="lazy float-left ml-2 col-md-2 img-responsive mt-0" width="128px" height="128px" alt="">
    <?php endif; ?>

    
    <h1 class="display-4 font-weight-bold" style="margin:0 0 0 0;"><?php echo e($name); ?></h1></a>
    

  
    <div class="clearfix"></div>
<div class="ml-2 mt-2" align="center">
 <?php if(auth::check() && auth::user()->channel_name != null && auth::user()->channel_name != $channel): ?>
          <?php if(isset($ckfollow)): ?>
        <form action="<?php echo e(route('unsubscribe')); ?>" method='POST'>
        <?php echo e(csrf_field()); ?>

          <input type="hidden" value="<?php echo e($channel); ?>" name="name">
          <button class="btn btn-secondary" type="submit"><i class="fas fa-user-times"></i> unfollow [<?php echo e($subscribe); ?>] </button>
        </form>
                  <?php else: ?>      
      
      <form action="<?php echo e(route('subscribe')); ?>" method='POST'>
        <?php echo e(csrf_field()); ?>

        <input type="hidden" value="<?php echo e($channel); ?>" name="name">
        <button type="submit" class="btn btn-info my-2"><i class='fas fa-check'></i> Follow </button>
      </form>
        <?php endif; ?>
        <?php else: ?>
        <div class="input-group col-md-2">
        <div class="input-group-prepend">
          <?php if(auth::check()): ?>
          <button class="btn btn-secondary" type="button" ata-toggle="tooltip" data-placement="top" title="This is your channel." disabled>Follows</button>
        <?php else: ?>
          <button class="btn btn-secondary" type="button" ata-toggle="tooltip" data-placement="top" title="Login to follow" disabled>Follows</button>        
          <?php endif; ?>
        </div>
        <input type="text" class="form-control text-right" value="<?php echo e($subscribe); ?>" disabled>
      
        </div>
      <?php endif; ?>
</div>
</div>

</section>
<div class="container">
<?php $__currentLoopData = $vines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row">
 <div class="col-md-2">
<div class="mb-3">
           <h5 class="bg-info rounded-right p-1 pl-2 text-white">Latest</h5>
          

          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/<?php echo e($feed->channel_name); ?>/<?php echo e($feed->id); ?>">
          <div class="bg-light border border-info mb-2 rounded p-1">
          <span class="font-weight-bold"><?php echo e($feed->title); ?></span>
          <small class="text-muted"> <?php echo e($feed->server); ?></small>
          <?php if($feed->type=='0'): ?>
        
          <img src="/images/default.jpg" data-src="/images/uploads/<?php echo e($feed->link); ?>" alt="<?php echo e($feed->title); ?>" class="lazy rounded border img-responsive" style="width:100%;height:auto;max-height:118px;">
          
        

          <?php else: ?>
          <?php $q = explode('=', $feed->link);?>
          <img class="lazy card-img-top rounded border img-responsive" data-src="http://img.youtube.com/vi/<?php echo e($q[1]); ?>/hqdefault.jpg" src="/images/default.png" style="width:100%;height:auto;max-height:118px;" alt="">

          <?php endif; ?>
          <small class="text-muted"><?php echo e(Carbon\Carbon::parse($feed->created_at)->format('d/m/Y H:i')); ?></small>
          </div>
          </a>
          <div class="clearfix"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <a href="/<?php echo e($feed->channel_name); ?>"><p class="text-center text-primary font-weight-bold">See all</p></a>

        </div>
      </div>


        <div class="col-md-8">
      <?php if($value->type == '0'): ?>
        
        <img class="lazy-fade tibiavines-watch img-responsive rounded border" src="/images/default.jpg" data-src="/images/uploads/<?php echo e($value->link); ?>" alt="Opa" style="max-width: 100%; height: auto;">
                <?php else: ?>

  <?php 
  $q = explode('=', $value->link )?>

        <div class="embed-responsive embed-responsive-16by9">
          <iframe src="https://www.youtube.com/embed/<?php echo e($q[1]); ?>?rel=0&amp;showinfo=0&amp;autoplay=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen class="lazy-fade tibiavines-watch embed-responsive-item rounded border"></iframe>
        </div>
        
        <?php endif; ?>
        <div class="col-md-8">
          <small><?php echo e(Carbon\Carbon::parse($value->created_at)->format('d/m/Y H:i')); ?> • <button type="button" class="border-0 bg-transparent" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Report</button></small>
    <h4 class="font-weight-bold "><?php echo e($value->title); ?>       
        <small class="text-muted"><?php echo e($value->server); ?></small>        
      </h4>
      <p><?php echo e($value->description); ?></p>
      <?php if( isset ($errors) && count($errors) > 0): ?>
              <div class="alert alert-danger rounded">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>

             <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
            <?php endif; ?>   
            
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Report photo or user</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo e(route('addReport')); ?>">
          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="page_id" value="<?php echo e($value->id); ?>">
          <input type="hidden" name="page_title" value="<?php echo e($value->title); ?>">
          <input type="hidden" name="channel_name" value="<?php echo e($channel); ?>">       
          <div class="form-group">
            <label for="title" class="col-form-label">Reason:</label>
            <select name="title" class="form-control" id="title">
              <option disabled selected>Select reason</option>

              <option value="nudity">Contains nudity</option>
              <option value="offensive">Offensive</option>
              <option value="personal image">Personal image</option>
              <option value="non-original content">Non-original content</option>
              <option value="identity theft">Identity theft</option>
            </select>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Message:</label>
            <textarea class="form-control" name="message" id="message-text"></textarea>
          </div>        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">Send Report</button>
      </div>
      </form>
    </div>
  </div>
</div>       
       
    </div>
<!-- 
        @INICIO  DO FEED COMENTÁRIOS
        @INICIO  DO FEED COMENTÁRIOS        
       -->
      
      <div class="card border-0">
        <h5 class="bg-info rounded p-1 pl-2 text-white">Comments</h5>
        <div class="card-body scroll-box">
          <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="clearfix">
            <a href="/<?php echo e($comentario->channel_name); ?>">
            <?php if($comentario->image): ?>
            <img src="/images/profile-images/<?php echo e($comentario->image); ?>" class="float-left mr-2 rounded-circle" width="32" height="32" >
            <?php else: ?>
            <img src="/images/profile-images/default.png" class="float-left mr-2 rounded-circle" width="32" height="32" >
            <?php endif; ?>
            </a>
            <?php if(auth::check() && $comentario->user_id == auth::user()->id): ?>
            <form action="<?php echo e(route('commentDelete')); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <a href="" class="text-muted float-right">
                <input type="hidden" value="<?php echo e($comentario->id); ?>" name="id">
                <input type="hidden" value="<?php echo e($value->id); ?>" name="id_page">
                <button type="submit" class="border-0 text-muted bg-white btn"> <i class="fas fa-times"></i></button>
              </form>
            </a>
            <?php endif; ?><a href="/<?php echo e($comentario->channel_name); ?>">
            <div class="content-heading"><h5><?php echo e($comentario->channel_name); ?></h5></div>
            </a>
          </div>
                  <span class="card-text"><?php echo e($comentario->comment); ?></span><br>
          <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($comentario->created_at)->diffForHumans()); ?></small>
          <hr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="card-footer bg-transparent">
          <?php if(Auth::check() && auth::user()->channel_name != null): ?>
          <form action="<?php echo e(route('insertComment')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="page_id" value="<?php echo e($value->id); ?>">
            
            <div class="container">
              <textarea name="comment" id="myText" cols="30" rows="10"></textarea>
            </div>
            <button type="submit" class="btn btn-info float-right mt-1 mr-3 rounded">Send</button>
              
              
          </form>
          <?php if( isset ($errors) && count($errors) > 0): ?>
          <div class="alert alert-danger rounded">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?><br />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <?php endif; ?>
          <?php else: ?>
          <div class="input-group mb-3">
            <input type="text" class="form-control" value="You are not logged in or no have channel" name="comment" aria-label="Recipient's username" aria-describedby="basic-addon2" disabled>
            <div class="input-group-append">
              <button class="btn btn-outline-secondary" disabled type="submit"><i class="fas fa-share-square"></i></button>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
      
    

    <!-- 
      @FIM  DO COMENTÁRIOS FEED 
    -->
        </div>

    <div class="col-md-2">
<div class="mb-3">
          <h5 class="bg-info rounded-left p-1 pl-2 text-white">Recomend</h5>

          <?php $__currentLoopData = $follow->unique('channel_name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="/<?php echo e($fav->channel_name); ?>">
          <div class="bg-light border border-info mb-2 rounded p-1">
          <span class="font-weight-bold"><?php echo e($fav->channel_name); ?></span>
           <?php if($fav->type=='0'): ?>
        
          <img src="/images/uploads/<?php echo e($fav->link); ?>" alt="<?php echo e($fav->title); ?>" class="rounded border img-responsive" style="width:100%;height:auto;max-height:118px;" >
          
        

          <?php else: ?>
          <?php $q = explode('=', $fav->link);?>
          <img class="card-img-top rounded border img-responsive" style="width:100%;height:auto;" src="http://img.youtube.com/vi/<?php echo e($q[1]); ?>/hqdefault.jpg" alt="">

          <?php endif; ?>
          <small class="text-muted"><?php echo e(Carbon\Carbon::parse($fav->created_at)->format('d/m/Y H:i')); ?></small>
          </div>
          </a>
          <div class="clearfix"></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

        <div>
          <h5 class="bg-info rounded-left p-1 pl-2 text-white">Publicity</h5>
          <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Publicity -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4248007486386492"
     data-ad-slot="5852868154"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
    
        </div>
      </div>


        
      </div>

    </div>
    


      <!-- /.row -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

      <!-- Page Features -->
     
      </div>
      <!-- /.row -->
    </div>

    
    <!-- /.container -->
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('footer'); ?>
 <footer class="page-footer rounded-top font-small">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2018 Copyright:
    <a href="/"> TibiaVines.com</a>
  </div>
  <!-- Copyright -->

</footer>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_channel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>