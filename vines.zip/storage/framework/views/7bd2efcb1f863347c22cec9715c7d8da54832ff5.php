<?php if(count($data) > 0): ?>
<div class="col-md-12" align="center">
          <div class="card mb-4 col-md-8 border-0 text-left">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($value->type=='0'): ?>
                  <?php $img = "<i class='fas fa-image'></i>"; ?>
                <?php else: ?>
                  <?php $img = "<i class='fas fa-video'></i>"; ?>
                <?php endif; ?>

          <!-- Blog Post -->
          
            <?php if($value->type =='0'): ?>

            <img class="lazy img-responsive" style="max-width: 100%; height: auto;" data-src="/images/uploads/<?php echo e($value->link); ?>" src="/images/default.jpg" />

            <?php else: ?>

              <?php $q = explode('=', $value->link ); ?>
            <div class="embed-responsive embed-responsive-16by9">
          <iframe src="https://www.youtube.com/embed/<?php echo e($q[1]); ?>?rel=0&amp;showinfo=0&amp;autoplay=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen class="lazy embed-responsive-item rounded border"></iframe>
        </div>
            <?php endif; ?>



            <div class="card-body">
              <h2 class="card-title"><?= $img ?> <?php echo e($value->title); ?></h2>
              <p class="card-text"><?php echo e($value->description); ?></p>
              <p class="card-text text-muted"><?php echo app(App\Http\Controllers\commentController::class)->countComment($value->id); ?> comments</p>
              <a href="/<?php echo e($value->channel_name); ?>/<?php echo e($value->id); ?>" class="btn btn-info">Go to Post</a>
            </div>
            <div class="card-footer text-muted">
              Posted <?php echo e(Carbon\Carbon::parse($value->created_at)->diffForHumans()); ?>

            </div>

          <hr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <?php endif; ?>

          