<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-lg-3 col-md-5" style="padding:0 5px 0 0;">
              <div class="card rounded border-0 bg-transparent">
                <?php if($value->type=='0'): ?>
                  <?php $img = "<i class='fas fa-image'></i>"; ?>
                <?php else: ?>
                  <?php $img = "<i class='fas fa-video'></i>"; ?>
                <?php endif; ?>
                  <?php if($value->type == '0'): ?>
                  <a href="<?php echo e($value->channel_name); ?>/<?php echo e($value->id); ?>">
                <img class="card-img-top img-responsive"  src="/images/uploads/<?php echo e($value->link); ?>" alt="" style="max-width: 100%;height: auto;width:210px;height:118px;"></a>
                  <?php else: ?>
                <?php $q = explode('=', $value->link);?>
                <a href="<?php echo e($value->channel_name); ?>/<?php echo e($value->id); ?>"><img class="card-img-top img-responsive" src="http://img.youtube.com/vi/<?php echo e($q[1]); ?>/hqdefault.jpg" style="max-width: 100%;height: auto;width:210px;height:118px;"></a>
              
                <?php endif; ?>

                <div class="card-body">
                  <span class="card-title font-weight-bold">
                    <a href="<?php echo e($value->channel_name); ?>/<?php echo e($value->id); ?>"><?= $img ?> <?php echo e($value->title); ?></a>
                  </span>
                  <div class="clearfix"></div>                
                  <small class="text-muted"><i class="fas fa-globe-americas"></i> <?php echo e($value->server); ?></small>
                  <div class="clearfix"></div>
                  <a href="/<?php echo e($value->channel_name); ?>" class="hover-href"><small class=""><i class="fas fa-book"></i> <?php echo e($value->channel_name); ?></small></a>
                  <div class="clearfix">
                  <small class="text-muted"><i class="far fa-eye"></i> <?php echo e($value->view); ?></small>
                  <div class="clearfix"></div>
                  <small class="text-muted">  <?php echo e(Carbon\Carbon::parse($value->created_at)->diffForHumans()); ?></small>
                  </div>

                                    
                 </div>

              </div>
            </div>
 

  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>