<?php $__env->startSection('title', 'TibiaVines - Control panel'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            Regras:
                        </div>
                        <div class="card-body">
                            <div class="card pl-3 pt-3">
                                Sobre:<br>
                                Olá, você esta pronto para criar o seu canal TibiaVines, mas para isso precisa estar de acordo com as regras, e entendê-las. Vamos lá:<br><br>
                                <span class="font-weight-bold">1: Apenas aceitamos videos do seu criador.</span><br>
                                <span class="font-weight-bold">2: The <a href="keycode.html">KeyCode</a> é um codigo publico que deve esta na descrição do video a ser enviado.</span>
                                <br>
                                <span class="font-weight-bold">3: Nomes ofensivos ou de terceiros não são permitidos no canal.</span><br>
                                <span class="font-weight-bold">4: O conteúdo postado deve ser relacionado ao jogo Tibia.</span><br>
                                <span class="font-weight-bold">5: Ao seguir você está concordando e entende as regras.</span><br>
                                <span class="font-weight-bold text-danger"> Caso alguma dessas regras forem quebradas você poderá ter seu perfil banido.</span><br>
                                <form action="create_channel.html" method="POST">
                                    <input type="hidden"  name="rule_code">
                                    <button class="mb-3 form control btn btn-info" name="read_terms">
                                    Beleza, Entendi!
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>