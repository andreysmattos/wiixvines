<?php $__env->startSection('channel_menu', 'active'); ?>


<?php $__env->startSection('col-padrao', 'col-lg-12'); ?>

<?php $__env->startSection('feed_vines'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('loop_vines'); ?>

<?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="col-lg-3 col-md-5 mb-3">
              <div class="card rounded">
                  <a href="/<?php echo e($value->name); ?>">
                <a href="<?php echo e($value->name); ?>">
                	<?php if($value->image): ?>
                	<img class="card-img-top img-responsive" src="/images/profile-images/<?php echo e($value->image); ?>" style="max-width: 100%;height: auto;">
                	<?php else: ?>
                	<img class="card-img-top img-responsive" src="/images/profile-images/default.png" style="max-width: 100%;height: auto;">

                	<?php endif; ?>

                </a>


                <div class="card-body">
                  <span class="card-title font-weight-bold">
                    <a href="/<?php echo e($value->name); ?>"><?php echo e($value->name); ?></a>
                  </span>
                  <div class="clearfix"></div>
                  <?php echo e($value->description); ?>

                  <hr>

                  <small class="text-muted"><i class="fas fa-globe-americas"></i> <?php echo e(Carbon\Carbon::parse($value->created_at)->diffForHumans()); ?></small>
                  <div class="clearfix"></div>
                  <small class="text-muted"><i class="fas fa-bookmark"></i> <?php echo e($value->subscribe); ?> following</small>    
                  <div class="clearfix"></div>            

                  <a href="/<?php echo e($value->name); ?>" class="hover-href"><small class=""><i class="fas fa-book"></i> <?php echo e($value->name); ?></small></a>

                  <div class="clearfix">
                  <div class="clearfix"></div>
                  </div>

                                    
                 </div>

              </div>
            </div>
 

	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div class="row bg-light col-12">
    <?php echo e($channels->render("pagination::bootstrap-4")); ?>

  </div>

  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('footer'); ?>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>