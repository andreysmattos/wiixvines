 <?php if(Auth::check()): ?>

           

          <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo e(Auth::user()->nick); ?>

                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a href="/user/control-panel" class="dropdown-item">
                                    <i class="pr-2 fas fa-tachometer-alt"></i> Dashboard
                                </a>
                                <div class="dropdown-header bg-light text-center">Channel</div>
                                <?php if(auth::user()->channel_name != null): ?>
                                <a href="/<?php echo e(auth::user()->channel_name); ?>" class="dropdown-item">
                                    <i class="fas fa-images"></i> My Channel
                                </a>
                                <?php else: ?>
                                <a href="/user/create-channel" class="dropdown-item">
                                    <i class="fas fa-images"></i> Create Channel
                                </a>
                                <?php endif; ?>
                                
                                <a href="/user/upload-photo" class="dropdown-item">
                                    <i class="pr-2 fas fa-cloud-upload-alt"></i>Upload Photo
                                </a>

                                <a href="/user/upload-vine" class="dropdown-item">
                                    <i class="pr-2 fas fa-cloud-upload-alt"></i>Upload Vine
                                </a>
                                <a href="/user/vines" class="dropdown-item">
                                    <i class="pr-2 far fa-file-video"></i> Vine management
                                </a>
                                <a href="/user/studio" class="dropdown-item">
                                    <i class="pr-2 fas fa-cog"></i> Channel studio
                                </a>
                                <div class="dropdown-header bg-light text-center">Perfil</div>
                                <a href="/user/settings" class="dropdown-item">
                                    <i class="pr-2 fa fa-wrench"></i> Personal Settings
                                </a>
                                <div class="dropdown-divider"></div>
                                <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();  document.getElementById('logout-form').submit();" class="dropdown-item">
                                    <i class="pr-2 fa fa-lock"></i> Logout
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </div>
                        </li>
            <?php else: ?>
 <ul class="nav navbar-nav flex-row justify-content-between ml-auto">
                
                <li class="dropdown order-1">
                    <button type="button" id="dropdownMenu1" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">Login <span class="caret"></span></button>
                    <ul class="dropdown-menu dropdown-menu-right mt-2">
                       <li class="px-3 py-2">
                           <form class="form" role="form" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <input id="emailInput" name="email" placeholder="Email" class="form-control form-control-sm" type="text" required>
                                    <?php if($errors->has('email')): ?>                                  
                                        <small class="text-danger"><?php echo e($errors->first('email')); ?></small>
                                    
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <input id="passwordInput" name="password" placeholder="Password" class="form-control form-control-sm" type="password" required>
                                    <?php if($errors->has('password')): ?>
                                 <small class="text-danger"><?php echo e($errors->first('password')); ?></small>
                                    
                                <?php endif; ?>
                                </div>
                                
                                <div class="form-group">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                                    </label>
                                </div>
                                    <button type="submit" class="btn btn-info btn-block">Login</button>
                                    
                                </div>
                                <div class="form-group text-center">
                                    <small><a href="<?php echo e(route('password.request')); ?>" class="btn btn-link">Forgot password?</a></small>
                                </div>
                            </form>
                        </li>
                    </ul>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
            </li>

            <?php endif; ?>

      
          </ul>