<?php $__env->startSection('feed_vines'); ?>
<div class="input-group col-sm-10 col-md-8 container mb-2" id="buscar-container">
	<input type="text" class="form-control" placeholder="Estou procurando por..." aria-label="Recipient's username" aria-describedby="basic-addon2">
	<div class="input-group-append">
		<button class="btn btn-outline-info" type="button">Procurar</button>
	</div>
</div>

<form class="form-inline d-flex justify-content-center bg-light pt-2 mb-2" action="" method="POST">
	<div class="form-group mb-2">
		<label for="pvptype" class="pl-1">PvP Type:</label>
		<select class="custom-select" id="pvptype" name="pvptype">
			<option value=""></option>
		</select>
	</div>
	<div class="form-group mb-2">
		<label for="worldtype" class="pl-1">Server:</label>
		<select class="custom-select" id="worldtype" name="world">
			
		</select>
	</div>
	<div class="form-group mb-2">
		<label for="modetype" class="pl-1">Modo de Jogo:</label>
		<select class="custom-select" id="modetype" name="mode">
			<option value="All" selected>All</option>
			<option value="0">PvP</option>
			<option value="1">PvE</option>
			<option value="2">Quests</option>
		</select>
	</div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('loop_vines'); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul id="tiles" class="innercontnt">
	<li>
		<a href="/watch?v=<?php echo e($value->id); ?>">
			<?php $q = explode('=', $value->link);
			
?>
			<img src="http://img.youtube.com/vi/<?php echo e($q[1]); ?>/hqdefault.jpg" >
			<div class="post-info">
				<div class="post-basic-info">
					<h3><a href="#" class="text-info font-weight-normal"><?php echo e($value->title); ?></a></h3>
					<span><a href="#" class="text-dark text-capitalize"><i class="fas fa-globe-americas"></i> <?php echo e($value->server); ?></a></span>
					<p class="font-weight-normal"><?php echo e($value->description); ?></p>
				</div>
			</a>
			<div class="post-info-rate-share">
				<div class="rateit">
					<i class="ml-2 fas fa-eye"></i> 
				</div>
				<div class="post-share">
					<span class="text-capitalize">
						<i class="fas fa-book"></i> <?php echo e($value->channel_name); ?>

					</span>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
	</li>
	</u>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>