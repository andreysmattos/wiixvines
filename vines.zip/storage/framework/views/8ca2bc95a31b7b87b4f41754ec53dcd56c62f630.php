<?php $__env->startSection('bg_color', ''); ?>
<?php $__env->startSection('ch_color', ''); ?>
<?php 
$bg_header = "";
$ch_name_color = "";
$ch_desc_color = "";

$title_color = "";
$subtitle_color = "";

$text_color = "";
$hr_color ="";

?>



<?php $__env->startSection('col-padrao', 'col-lg-12'); ?>

<?php $__env->startSection('feed_vines'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('loop_vines'); ?>
<div class="col-md-12" align="center">
  <div class="card border col-md-12" style="width: 18rem;">
  <img class="card-img-top" src="/images/no-exit.png" alt="Card image cap">
  <div class="card-body">
    <h1 class="card-title font-weight-bold"><?php echo e($usernick); ?></h1>
    <p class="card-text">This user no have channel or does not exist.</p>
  </div>
</div>
</div>


  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('footer'); ?>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_channel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>