<!DOCTYPE HTML>
<html>
	<head>
		<title>TibiaVines - Feed</title>
		<link href="css/style.css" rel='stylesheet' type='text/css' />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="shortcut icon" type="image/x-icon" href="images/fav-icon.png" />
		<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
		</script>
		<!----webfonts---->
		<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
		<!----//webfonts---->
		<!-- Global CSS for the page and tiles -->

		<link href="<?php echo e(asset('/css/main.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('/css/all.css')); ?>" rel="stylesheet">
		<link href="<?php echo e(asset('/js/bootstrap.bundle.js')); ?>" rel="script">
		<link href="<?php echo e(asset('/font-awesome/css/all.css')); ?>" rel="stylesheet">
		
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
		<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
	</head>
	<body>
		<!---start-wrap---->
		<!---start-header---->
		<div class="header order-first">
			<div class="wrap container">
				<div class="logo col-md-2 col-sm-4 col-6">
					<a href="/"><img src="<?php echo e(URL::asset('images/logo.png')); ?>" title="pinbal" /></a>
				</div>
				<div class="hidelogin col-md-1 col-sm-1 col-xs-1 col-1 rounded-circle cursor_pointer btn-info btn-outline-info border border-info mt-2 pt-2 pb-2 ml-2" id="login-click"><a href="login.html" class="text-info"><i class="fas fa-sign-in-alt d-flex justify-content-center"></i></a></div>
				<div class="allsearch mx-auto">
					<div class="input-group col-md-5 top-searchbar">
						<input type="text" class="form-control" placeholder="Estou procurando por..." aria-label="I want see.." aria-describedby="basic-addon2" id="search_all">
						<div class="input-group-append">
							<button type="submit" class="btn-info btn submitb btn-outline-info mt-2">Procurar</button>
						</div>
					</div>
				</div>
				
				<div class="userinfo">
					
				</div>

				<div class="userinfo mx-auto">
					<div class="user">
						<ul>
							<li>
								<div class="above-login font-weight-bold ml-4"><span class="col"><a href="register.html" class="text-info">Cadastre-se!</a></span>
								<span class="col"><a href="#" class="text-info">Esqueceu a senha?</a></span>
							</div>
							<form method="POST" action="">
								<div class="form-row formlogin mt-2">
									<div class="form-group">
										<input type="text" class="rounded-left border border-info pl-2" name="login" placeholder="Login" required>
									</div>
									<div class="form-group">
										<input type="password" class="border border-info pl-2" name="pass" placeholder="Senha" required>
										<input type="hidden" name="log" value="in" >
									</div>
									
									<div class="form-group">
										<button type="submit" class="rounded-right cursor_pointer btn-info btn-outline-info border border-info pl-2" id="submitlogin" name="submitlogin"><i class="fas fa-sign-in-alt"></i></button>
									</form>
								</div>
								
							</div>
						</div>
						
					</li>
					
				</ul>
			</div>
		</div>
	</div>
	<div class="clear"> </div>
</div>
</div>
<!---//End-header---->

<!---start-content---->
<div class="content">
<div class="wrap">
	<div class="wrap">
			<div class="single-page">

				<?php echo $__env->yieldContent('watch'); ?>
			</div>
		</div>
</div>
</div>
<!---//End-content---->
<!----wookmark-scripts---->
<script src="js/jquery.imagesloaded.js"></script>
<script src="js/jquery.wookmark.js"></script>
<script type="text/javascript">
(function ($){
var $tiles = $('#tiles'),
$handler = $('li', $tiles),
$main = $('#main'),
$window = $(window),
$document = $(document),
options = {
autoResize: true, // This will auto-update the layout when the browser window is resized.
container: $main, // Optional, used for some extra CSS styling
offset: 20, // Optional, the distance between grid items
itemWidth:280 // Optional, the width of a grid item
};
/**
* Reinitializes the wookmark handler after all images have loaded
*/
function applyLayout() {
$tiles.imagesLoaded(function() {
// Destroy the old handler
if ($handler.wookmarkInstance) {
$handler.wookmarkInstance.clear();
}

// Create a new layout handler.
$handler = $('li', $tiles);
$handler.wookmark(options);
});
}
/**
* When scrolled all the way to the bottom, add more tiles
*/

// Call the layout function for the first time
applyLayout();

// Capture scroll event.
$window.bind('scroll.wookmark', onScroll);
})(jQuery);
</script>
<!----//wookmark-scripts---->
<!----start-footer--->
<!----//End-footer--->
<!---//End-wrap---->
</body>
</html>