<?php $__env->startSection('menu'); ?>
        <div class="sidebar">
        
            <nav class="sidebar-nav" id="sidebar">
                <ul class="nav">
                    <li class="nav-title">Dashboard</li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Sumary
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="last-interactions" class="nav-link">
                            <i class="fab fa-angellist"></i> Latest interactions 
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link">
                            <i class="fas fa-address-book"></i> Subscribes
                        </a>
                    </li>


                    <li class="nav-title">Channel Library</li>

                    <li class="nav-item">
                        <a href="upload-photo" class="nav-link">
                            <i class="fas fa-image"></i> Upload Photo
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="upload-vine" class="nav-link">
                            <i class="fas fa-video"></i> Upload Vines
                        </a>
                    </li>
                
                    <li class="nav-item">
                        <a href="studio" class="nav-link" disabled>
                            <i class="fas fa-tasks"></i> Studio
                        </a>
                    </li>
                   
                    <li class="nav-item">
                        <a href="vines" class="nav-link">
                            <i class="fas fa-sliders-h"></i> Vines manager
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="settings" class="nav-link active">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </li>                 


                 </ul>
          
               </li>



                   
                </ul>
            </nav>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header bg-light">
                                Settings 
                            </div>
                              <?php if( isset ($errors) && count($errors) > 0): ?>
              <div class="alert alert-danger rounded">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>
                                
                                
                                        <?php if(session()->has('msgkeycode')): ?>
                                        <div class="alert alert-danger rounded">
                                            <?php echo e(session()->get('msgkeycode')); ?><br />
                                        </div>
                                         <?php echo e(session()->forget('msgkeycode')); ?>

                                        <?php endif; ?>

                            <div class="card-body">
                                <table class="table border-0">
                                    <tr class="border rounded"><td>Channel Name: </td><td> /<?php echo e(auth::user()->channel_name); ?></td></td><td></tr>                                 
                                    <tr class="border rounded"><td>Keycode: </td><td> <?php echo e($keycode); ?></td></td><td></tr>                                 

                                    <tr class="border rounded"><td>Email: </td><td id="email-area">•••••••••••••••••••••</td><td><button type="button" class=" float-right border-0 btn-outline-info" id="emailshow">Show</button></td></tr>
                                    <tr class="border rounded"><td>Login: </td><td id="login-area">•••••••••••</td><td><button type="button" class=" float-right border-0 btn-outline-info" id="loginshow">Show</button></td></tr>

                                    <tr class="border rounded">
                                        <td>Password: </td>
                                        <td>•••••••••••</td>
                                        <td>
                                            <a href="/user/change-password">
                                            <button type="button" class="float-right border-0 btn-outline-info">Reset</button>
                                            </a>
                                        </td>
                                    </tr>

                                    <tr class="border rounded"><td>Promoted?</td><td> No</td></td><td></tr>
                                    <tr class="border rounded"><td>Started:</td><td> <?php echo e(Carbon\Carbon::parse(auth::user()->created_at)->format('d/m/Y H:i')); ?></td></td></td><td></tr>                                   
                                </table>
                                                                <div class="row">

                                    <div class="col-md-12">

                            
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $('#emailshow').click(function(){
            if($('#emailshow').html() == 'Show'){
                $('#email-area').html('<?php echo e(auth::user()->email); ?>');
                $('#emailshow').html('Hide');
            }else{
                $('#email-area').html('•••••••••••••••••••••');
                $('#emailshow').html('Show');

            }
            
            
        })
        $('#loginshow').click(function(){
            if($('#loginshow').html() == 'Show'){
                $('#login-area').html('<?php echo e(auth::user()->login); ?>');
                $('#loginshow').html('Hide');
            }else{
                $('#login-area').html('•••••••••••');
                $('#loginshow').html('Show');

            }
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.layouts.newbase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>