<?php $__env->startSection('title', 'TibiaVines - Create Channel'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="">
    <div class="card pl-3 pr-4">
      <div class="card-header bg-light">
        Create Channel
      </div>
      <div class="card-body">
        <div class="row">
            <form method="POST" action="<?php echo e(route('channel.store')); ?>">
              <?php echo e(csrf_field()); ?>

              <?php if( isset ($errors) && count($errors) > 0): ?>
              <div class="alert alert-danger rounded">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
    $("#title").keyup(function(){
      var titleval = $("#title").val();
        $("#keycode").val(titleval);
    });  
    
});

</script>


              <div class="form-group">
                <label for="title" class="form-control-label">Channel name:</label>
                <input id="title" name="name" class="form-control" autocomplete="off" required value="<?php echo e(old('name')); ?>">
                <div id="titleerro" class="text-danger pl-3 font-weight-light"></div>
              </div>
        </div>
        <div class="row">
              <div class="form-group">
                <label for="title" class="form-control-label">This is your keycode.</label>
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="fm">TibiaVines.com/</span>
                  </div>
                  <input type="text" class="form-control" id="keycode" name="keycode" autocomplete='off' required maxlength="15" minlength="4"  value="<?php echo e(old('name')); ?>" readonly>

                </div>

               </div>
        </div>
        <div class="row">
          <div class="form-group">
            <label for="desc" class="form-control-label">Description Channel:</label>
            <div class="input-group">
           <textarea name="description" class="form-control" id="desc" cols="30" maxlength='150' minlength="5" rows="5"><?php echo e(old('description')); ?></textarea>
         </div>
          </div>
        </div>
          <button type="submit" class="mt-3 form-control rounded cursor_pointer btn btn-info btn-outline-info border border-info font-weight-bold">Create Channel</button>
          
        </form>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.layouts.base', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>