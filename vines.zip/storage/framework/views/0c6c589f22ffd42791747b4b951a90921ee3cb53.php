<?php $__env->startSection('menu'); ?>
        <div class="sidebar">
        
            <nav class="sidebar-nav" id="sidebar">
                <ul class="nav">
                    <li class="nav-title">Dashboard</li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link ">
                            <i class="fas fa-tachometer-alt"></i> Sumary
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="last-interactions" class="nav-link">
                            <i class="fab fa-angellist"></i> Latest interactions 
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link">
                            <i class="fas fa-address-book"></i> Subscribes
                        </a>
                    </li>


                    <li class="nav-title">Channel Library</li>

                    <li class="nav-item">
                        <a href="upload-photo" class="nav-link">
                            <i class="fas fa-image"></i> Upload Photo
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="upload-vine" class="nav-link">
                            <i class="fas fa-video"></i> Upload Vines
                        </a>
                    </li>
                
                    <li class="nav-item">
                        <a href="studio" class="nav-link active" disabled>
                            <i class="fas fa-tasks"></i> Studio
                        </a>
                    </li>
                   
                    <li class="nav-item">
                        <a href="vines" class="nav-link">
                            <i class="fas fa-sliders-h"></i> Vines manager
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link disabled">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </li>                 


                 </ul>
          
               </li>



                   
                </ul>
            </nav>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-header bg-light">
                                Channel Settings
                            </div>
                              <?php if( isset ($errors) && count($errors) > 0): ?>
              <div class="alert alert-danger rounded">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                            <div class="card-body">
    
                                <div class="row">

                                    <div class="col-md-12">

<?php echo e(Form::open(['route' => 'channelUpdate', 'files' => true])); ?>

                                        <div class="form-group">
                                            <label for="title" class="form-control-label">Profile Image</label>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!$value->image): ?>
                                            <img src="/images/profile-images/default.png" width="128px" id="blah" height="128px;" class="border float-left mr-3" alt="">
                                            <?php else: ?>
                                            <img src="/images/profile-images/<?php echo e($value->image); ?>" width="128px" id="blah" height="128px;" class="border float-left mr-3" alt="">
                                            <?php endif; ?>


                                            <div id="titleerro" class="text-danger pl-3 font-weight-light"></div>
                                        </div>
                                    </div>
                                   </div>      
                                   <br>
                             <div class="row mb-2">
                                 <div class="col-md-12" id="ybform">
                                    <div class="form-group">
                                    <label for="yblink">Photo: </label>
                                        <div class="input-group">
                                            
                                                <?php echo e(Form::file('link', array('id' => 'imgInp'))); ?>

                                    
                                        </div>
                                        <span class="text-danger" id="linkerror">We use 128x128 profile images.</span>
                                        </div>
                                        
                                </div>
                                
                            </div>

                            <div class="row">


                                </div>
                                
                                   <div class="row">
                                    <div class="col-md-12">  
                                        <div class="form-group">
                                 <div class="input-group">

    <label for="desc">Channel description:</label>
  </div> <textarea class="form-control" aria-label="With textarea" id="desc" name="description" maxlength="200" rows="5"><?php echo e($value->description); ?></textarea>
  

<div id="descerro" class="text-danger pl-3 font-weight-light"></div>
</div>
</div>
</div>

<button type="submit" class="form-control rounded cursor_pointer btn btn-info btn-outline-info border border-info font-weight-bold">Update</button>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e(Form::close()); ?>


            </div>
        </div>
    </div>
</div>
<script>
    function readURL(input) {

  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
      $('#blah').attr('src', e.target.result);
    }

    reader.readAsDataURL(input.files[0]);
  }
}

$("#imgInp").change(function() {
  readURL(this);
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.layouts.newbase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>