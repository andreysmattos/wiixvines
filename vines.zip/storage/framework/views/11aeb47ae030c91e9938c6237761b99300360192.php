<?php $__env->startSection('menu'); ?>
        <div class="sidebar">
        
            <nav class="sidebar-nav" id="sidebar">
                <ul class="nav">
                    <li class="nav-title">Dashboard</li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Sumary
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="last-interactions" class="nav-link">
                            <i class="fab fa-angellist"></i> Latest interactions 
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link">
                            <i class="fas fa-address-book"></i> Subscribes
                        </a>
                    </li>


                    <li class="nav-title">Channel Library</li>

                    <li class="nav-item">
                        <a href="upload-photo" class="nav-link">
                            <i class="fas fa-image"></i> Upload Photo
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="upload-vine" class="nav-link">
                            <i class="fas fa-video"></i> Upload Vines
                        </a>
                    </li>
                
                    <li class="nav-item">
                        <a href="studio" class="nav-link" disabled>
                            <i class="fas fa-tasks"></i> Studio
                        </a>
                    </li>
                   
                    <li class="nav-item">
                        <a href="vines" class="nav-link active">
                            <i class="fas fa-sliders-h"></i> Vines manager
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="control-panel" class="nav-link disabled">
                            <i class="fas fa-cog"></i> Settings
                        </a>
                    </li>                 


                 </ul>
          
               </li>



                   
                </ul>
            </nav>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
<div class="container-fluid">
                <div class="row">
                    <div class="col-md-10">
                        <div class="card">
                            <div class="card-header bg-light">
                                Vines Studio
                            </div>

                <div class="bg-light border">
                <table class="table table-striped table-hover">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Thumbnail</th>
      <th scope="col">Title</th>
      <th scope="col">Views</th>
      <th scope="col">Comments</th>
      <th scope="col"></th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
    <?php $i = 1; ?>
    <?php if($nothing == 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
    $q = explode('=', $value->link);
        ?>
    
        <tr>
         <th scope="row"><?php echo e($i); ?></th>
          <td>
            <?php if($value->type == '0'): ?>
                                            <img class="rounded border" src="/images/uploads/<?php echo e($value->link); ?>" alt="" width="75px" height="50px">
                                            <?php else: ?>
                                            <?php $q = explode('=', $value->link);?>
                                        <img class="rounded border" src="http://img.youtube.com/vi/<?php echo e($q[1]); ?>/hqdefault.jpg" alt="" width="75px" height="50px">
                                        <?php endif; ?>

            




          </td>
          <td><?php echo e($value->title); ?></td>
          <td><?php echo e($value->view); ?></td>
          <td><?php echo e($value->comments); ?></td>
          <td><a href="edit/<?php echo e($value->id); ?>"><button type="button" class="btn btn-danger rounded">Edit</button></a>              </td><td><form action="<?php echo e(route('deleteVine')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

      <input type="hidden" value="<?php echo e($value->id); ?>" name="id">
      <button type="submit" class="btn btn-warning rounded" onclick="return confirm('Are you sure you want to delete this item?');">Delete</button>
      </form></td>

        </tr>
    
    
<?php $i++; ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>

<tr>
    <th colspan="5" class="text-center">Nothing here...</th>
    
</tr>
<?php endif; ?>
  </tbody>
</table>
</div>
<script>
  jQuery(document).ready(function($) {
    $(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('painel.layouts.newbase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>