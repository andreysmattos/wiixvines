<?php $__env->startSection('menu'); ?>
        <div class="sidebar">
        
            <nav class="sidebar-nav" id="sidebar">
                <ul class="nav">
                    <li class="nav-title">Dashboard</li>

                    <li class="nav-item">
                        <a href="/admin" class="nav-link">
                            <i class="fas fa-tachometer-alt"></i> Sumary
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="/admin/reports" class="nav-link">
                            <i class="fab fa-angellist"></i> Reports 
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="/admin/comments" class="nav-link active">
                            <i class="fas fa-address-book"></i> Comments
                        </a>
                    </li>


                

                   
                </ul>
            </nav>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
          <!-- /.card -->
    <div class="row justify-content-center">
        <div class="col-md-12">
          <div class="card card-outline-secondary">
            <div class="card-header">
              Reports
            </div>
            <?php if( isset ($errors) && count($errors) > 0): ?>
              <div class="alert alert-danger rounded">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php endif; ?>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

            <div class="card-body">
                <table class="table table-hover">
                    <thead>
    <tr>
      <th scope="col">Nº</th>
      <th scope="col">PageTitle</th>
      <th scope="col">From</th>
      <th scope="col">To</th>
      <th scope="col">Comment</th>
      <th scope="col"></th>
      <th scope="col"></th>

    </tr>
  </thead>
  <tbody>
                        <?php $__currentLoopData = $com; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <tr>
                                <td><?php echo e($value->id); ?></th>
                                <td><?php echo e($value->page_title); ?></td>
                                <td><?php echo e($value->channel_name); ?></td>
                                <td><?php echo e($value->to_channel_name); ?></td>
                                <td><?php echo e($value->comment); ?></td>
                                <td><a href="/<?php echo e($value->to_channel_name); ?>/<?php echo e($value->page_id); ?>" target="_blank"><button type="button" class="btn btn-primary">Check</button></a></td>
                                <td>
                                  <form action="<?php echo e(url('/admin/delete-comment')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                  <input type="hidden" name="comment_id" value="<?php echo e($value->id); ?>">                                
                                  <button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja deletar este comentário?');">Delete Comment</button>
                                  </form> 
                                </td>
                            </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
          </div>
</div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin-panel.layout.basetemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>