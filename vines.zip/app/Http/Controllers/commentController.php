<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Comment;
use App\User;
use Illuminate\Support\Facades\Auth;

class commentController extends Controller
{
	 public function __construct(Comment $comment){
	 	$this->middleware('auth');
        $this->comment = $comment;
    }

    function insert(Request $request){

		$channelid = DB::table("channels")->where('user_id','=', auth::user()->id)->value('id');
        $selfchname = DB::table("channels")->where('user_id','=', auth::user()->id)->value('name');
		$targetchannelid = DB::table('vines')->where('id', '=', $request->input("page_id"))->value('channel_id');
        $tochannelname = DB::table('vines')->where('id', '=', $request->input("page_id"))->value('channel_name');
        $title = DB::table('vines')->where('id', '=', $request->input("page_id"))->value('title');
        $image = DB::table("channels")->where('user_id', '=', auth::user()->id)->value('image');
        if(!$image){
            $image = null;
        }

		$dataForm = [
			'user_id' =>	auth::user()->id,
			'page_id' =>	$request->input('page_id'),
			'channel_id' =>	$channelid,
			'to_channel_id' => $targetchannelid,
			'comment' =>	$request->input('comment'),
			'channel_name' => $selfchname ,
            'page_title' => $title,
            'to_channel_name' => $tochannelname,
            'image' => $image,

		];
		$this->validate($request, $this->comment->rules);
        $insert = $this->comment->create($dataForm);
        if($insert){
        	DB::table('vines')->where('id', '=', $request->input('page_id'))->increment('comments');
        	return back()->withInput();
        }else{
        	echo 'erro';
        }


    }

    function delete(Request $del){
    	$del->input('id');
    	$del->input('id_page');
    	$delete = DB::table('comments')->where('id', '=', $del->input('id'))->delete();
    	if($delete){
    		DB::table('vines')->where('id', '=', $del->input('id_page'))->decrement('comments');
    		return back()->withInput();
    	}
    	

    }

    function countComment($vine){
        $count = Comment::where('page_id', '=', $vine)->count();

        return $count;
    }
}
