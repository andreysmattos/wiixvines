<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Subscribe;
use App\User;
use Illuminate\Support\Facades\Auth;

class SubController extends Controller
{
    	public function __construct(Subscribe $subs)
    {
    	$this->subs = $subs;
        $this->middleware('auth');
        $this->middleware('authChannel');

    }

    public function subscribe(Request $request)
    {

    	$from_id = DB::table("channels")->where('user_id', '=', auth::user()->id)->value('id');
    	$from_name = DB::table("channels")->where('user_id', '=', auth::user()->id)->value('name');
    	
    	$to_name = $request->input('name');
    	$to_id = DB::table('channels')->where('name', '=', $to_name)->value('id');

		
		if($from_id == $to_id){
			return back()->withInput();

		}

    	$dataForm = [
			'from_channel_id' =>	$from_id,
			'from_channel_name' =>	$from_name,
			'to_channel_id' =>	$to_id,
			'to_channel_name' => $to_name,

		];



    	$this->validate($request, $this->subs->rules);
        $insert = $this->subs->create($dataForm);
        if($insert){
        	DB::table('channels')->where('id', '=', $to_id)->increment('subscribe');
        	return back()->withInput();
        }
    }

    public function unsubscribe(Request $request)
    {
    	$to_name = $request->input('name');
        $channelid = DB::table("channels")->where('user_id', '=', auth::user()->id)->value('id');
    	$delete = DB::table('subscribes')->where('from_channel_id', '=', $channelid)->where('to_channel_name', '=', $to_name)->delete();
    	if($delete){
    		DB::table('channels')->where('name', '=', $to_name)->decrement('subscribe');
    		return back()->withInput();
    	}else{
            session()->put('back_msg', 'An error has occurred, sorry!');
            return redirect('/');
        }
    }




}
