<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use App\Models\Viewer;

class ChannelView extends Controller
{
     private $vineview;

    public function __construct(Viewer $vineview){
        $this->vineview = $vineview;        
    
    }   

    function index($channel_name){

        $check = DB::table('channels')->where('name', '=', $channel_name)->value('id');


        if(isset($check)){

            $name = DB::table('channels')->where('name', '=', $channel_name)->value('name');
            $desc = DB::table('channels')->where('name', '=', $channel_name)->value('description');
            $id = DB::table('channels')->where('name', '=', $channel_name)->value('id');
            
            $subscribe =  DB::table('channels')->where('name', '=', $channel_name)->value('subscribe');

            $profileimg = DB::table('channels')->where('name', '=', $channel_name)->value('image');

            $check_default = DB::table('channels')->where('name', '=', $channel_name)->value('default_item');

             
            $item['item'] = DB::table('vines')->where('channel_id', '=', $check)->orderBy('id', 'desc')->limit(1)->get();

            if(!empty($check_default)){
                $item['item'] = DB::table('vines')->where('channel_id', '=', $check)->where('id', '=', $check_default)->limit(1)->get();
            }


            $data['data'] = DB::table('vines')->where('channel_id', '=', $check)->orderBy('id', 'desc')->paginate(12);

            if(auth::check()){
                $ckfollow = DB::table('subscribes')->where('from_channel_name', '=', auth::user()->channel_name)->where('to_channel_name', '=', $channel_name)->value('id');

                return view('channel_view', ['channel' => $channel_name, 'name' => $name, 'desc' => $desc,'subscribe' => $subscribe, 'ckfollow' => $ckfollow, 'profileimage' => $profileimg])->with($item)->with($data);
            }else{

                return view('channel_view', ['channel' => $channel_name, 'name' => $name, 'desc' => $desc, 'subscribe' => $subscribe, 'profileimage' => $profileimg])->with($item)->with($data);
            }                       


            
        }else{
            return view('404_watch');
        }


    }

        function show($channel, $vine){

        $check = DB::table('channels')->where('name', '=', $channel)->value('id');
        $vineexist = DB::table('vines')->where('id', '=', $vine)->value('id');
        if($check){
            if(!$vineexist){
                return redirect('/'.$channel);
            }
            $check2 = DB::table('vines')->where('channel_id', '=', $check)->where('id', '=', $vine)->value('id');
            
            $name = DB::table('channels')->where('name', '=', $channel)->value('name');
            $desc = DB::table('channels')->where('name', '=', $channel)->value('description');

            $vines['vines'] = DB::table('vines')->where('channel_id', '=', $check)->where('id', '=', $vine)->limit(1)->get(); 


            $data['data'] = DB::table('vines')->where('channel_id', '=', $check)->orderBy('id', 'desc')->limit(4)->get();    


            $follow['follow'] = DB::table('vines')->where('channel_name', '!=', $channel)->orderBy('created_at', 'desc')->limit(4)->get();


            $comments['comments'] = DB::table('comments')->where('page_id', '=', $vine)->orderBy('id', 'desc')->get();

            $profileimg = DB::table('channels')->where('name', '=', $channel)->value('image');

            //SUBSCRIBE VERIFY
            $id = DB::table('channels')->where('name', '=', $channel)->value('id');

            

            

            $subscribe =  DB::table('channels')->where('name', '=', $channel)->value('subscribe');


            // VIEW
            
            $ts = time() - 60;
            DB::table('totalview')->where('created_at', '<', Carbon::now()->subMinutes(600)->toDateTimeString())->delete();
            $check = DB::table('totalview')->where('visit_ip', '=', $_SERVER['REMOTE_ADDR'])->where('vine_id', '=', $vine)->get();       
            if (count($check) < 1)
                {
                $dataForm = ['vine_id' => $vine, 'visit_ip' => $_SERVER['REMOTE_ADDR'], ];
                $insert = $this->vineview->create($dataForm);
                $update = DB::table('vines')->where('id', '=', $vine)->increment('view');
                }
            // VIEW FIM                
            if(auth::check()){
            $auth_channelid = DB::table('channels')->where('user_id', '=', auth::user()->id)->value('id');
            $self_cname = DB::table('channels')->where('user_id', '=', auth::user()->id)->value('name');
            $ckfollow = DB::table('subscribes')->where('from_channel_id', '=', $auth_channelid)->where('to_channel_id', '=', $id)->value('id');

                 return view('watch', ['name' => $name, 'desc' => $desc, 'channel' => $channel, 'subscribe' => $subscribe, 'ckfollow' => $ckfollow, 'profileimage' => $profileimg])->with($vines)->with($data)->with($comments)->with($follow);


            }else{

                 return view('watch', ['name' => $name, 'desc' => $desc, 'channel' => $channel, 'subscribe' => $subscribe, 'profileimage' => $profileimg])->with($vines)->with($data)->with($comments)->with($follow);

            }
           
            
        
        }else{
            return redirect('/');
        }


    }
}
